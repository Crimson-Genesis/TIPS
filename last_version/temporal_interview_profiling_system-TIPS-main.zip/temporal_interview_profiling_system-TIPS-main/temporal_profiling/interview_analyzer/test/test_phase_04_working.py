#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'phases', 'phase_04_qa_segmentation'))

from process import process, export_plain_text_qa, export_csv_qa

if __name__ == "__main__":
    # Default to Phase 3 output if no args provided
    if len(sys.argv) != 2:
        transcript_path = "./data/intermediate/phase_03/test_video/test_video_transcript.json"
        print(f"Using default transcript path: {transcript_path}")
        print("Run with custom path: python test_phase_04_working.py <transcript_path>")
        print()
    else:
        transcript_path = sys.argv[1]
    
    try:
        print("Starting Phase 4 Q/A segmentation...")
        print(f"Transcript: {transcript_path}")
        print()
        
        result = process(transcript_path)
        qa_map = result['qa_map']
        
        print("Phase 4 Q/A segmentation completed successfully!")
        print(f"Q/A pairs saved to: {result['qa_path']}")
        print(f"Total duration: {qa_map['total_duration']} seconds")
        print(f"Original segments: {qa_map['statistics']['total_segments']}")
        print(f"Merged segments: {qa_map['statistics']['merged_segments']}")
        print(f"Q/A pairs found: {qa_map['statistics']['qa_pairs_found']}")
        
        # Show speaker mapping
        print(f"\nSpeaker mapping:")
        print(f"  Interviewer: {qa_map['speaker_mapping']['interviewer']}")
        print(f"  Candidate: {qa_map['speaker_mapping']['candidate']}")
        
        # Show Q/A pairs
        print(f"\nFirst few Q/A pairs:")
        for i, qa_pair in enumerate(qa_map['qa_pairs'][:3]):
            print(f"  Q{i+1}: [{qa_pair['question']['speaker']}] ({qa_pair['question']['start_time']:.2f}s - {qa_pair['question']['end_time']:.2f}s)")
            print(f"      {qa_pair['question']['text']}")
            print(f"  A{i+1}: [{qa_pair['answer']['speaker']}] ({qa_pair['answer']['start_time']:.2f}s - {qa_pair['answer']['end_time']:.2f}s)")
            print(f"      {qa_pair['answer']['text']}")
            print(f"      Duration: {qa_pair['total_duration']:.2f}s total, Gap: {qa_pair['gap_duration']:.2f}s")
            print()
        
        if len(qa_map['qa_pairs']) > 3:
            print(f"... and {len(qa_map['qa_pairs']) - 3} more Q/A pairs")
        
        # Export to plain text
        plain_text_path = os.path.join(os.path.dirname(result['qa_path']), "qa_pairs.txt")
        export_plain_text_qa(qa_map, plain_text_path)
        print(f"Plain text exported to: {plain_text_path}")
        
        # Export to CSV
        csv_path = os.path.join(os.path.dirname(result['qa_path']), "qa_pairs.csv")
        export_csv_qa(qa_map, csv_path)
        print(f"CSV exported to: {csv_path}")
        
        print(f"\n📁 Output directory: {os.path.dirname(result['qa_path'])}")
        print("📄 Files generated:")
        print("   - [audio_name]_qa_pairs.json (primary)")
        print("   - qa_pairs.txt (readable Q/A format)")
        print("   - qa_pairs.csv (tabular format)")
        
        # Show statistics
        stats = qa_map['statistics']
        print(f"\n📊 Statistics:")
        print(f"   Interviewer segments: {stats['interviewer_segments']}")
        print(f"   Candidate segments: {stats['candidate_segments']}")
        print(f"   Q/A success rate: {stats['qa_pairs_found']}/{stats['merged_segments']} ({stats['qa_pairs_found']/stats['merged_segments']*100:.1f}%)")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)