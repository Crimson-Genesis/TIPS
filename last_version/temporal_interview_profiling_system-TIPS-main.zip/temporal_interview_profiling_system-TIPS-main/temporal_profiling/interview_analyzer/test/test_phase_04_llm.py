#!/usr/bin/env python3

import sys
import os
import json
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'phases', 'phase_04_qa_segmentation'))

from process import process, OllamaClient
from pathlib import Path

def create_mislabeled_test_data():
    """Create test transcript with intentionally mislabeled speakers."""
    test_data = {
        "audio_file": "test_mislabeled.wav",
        "diarization_file": "test_diarization.json", 
        "total_duration": 60.0,
        "model": {
            "type": "whisper",
            "size": "base"
        },
        "segments": [
            {
                "speaker": "SPEAKER_1",  # Wrong: should be interviewer
                "start_time": 1.0,
                "end_time": 3.0,
                "duration": 2.0,
                "text": "Can you tell me about your experience with system design?",
                "language": "en",
                "confidence": None,
                "words": []
            },
            {
                "speaker": "SPEAKER_0",  # Wrong: should be candidate  
                "start_time": 4.0,
                "end_time": 8.0,
                "duration": 4.0,
                "text": "I have worked on several large-scale systems including distributed databases and microservices architectures.",
                "language": "en",
                "confidence": None,
                "words": []
            },
            {
                "speaker": "SPEAKER_1",  # Wrong: should be interviewer
                "start_time": 9.0,
                "end_time": 11.0,
                "duration": 2.0,
                "text": "What challenges did you face in those projects?",
                "language": "en", 
                "confidence": None,
                "words": []
            },
            {
                "speaker": "SPEAKER_0",  # Wrong: should be candidate
                "start_time": 12.0,
                "end_time": 16.0,
                "duration": 4.0,
                "text": "The main challenges were around consistency and scalability. We had to implement distributed consensus protocols.",
                "language": "en",
                "confidence": None, 
                "words": []
            },
            {
                "speaker": "SPEAKER_1",  # Wrong: should be interviewer
                "start_time": 17.0,
                "end_time": 18.0,
                "duration": 1.0,
                "text": "Thank you for sharing that.",
                "language": "en",
                "confidence": None,
                "words": []
            }
        ]
    }
    return test_data

def create_short_dialogue_test():
    """Create test data with short back-and-forth to stress small context."""
    test_data = {
        "audio_file": "test_short_dialogue.wav",
        "diarization_file": "test_diarization.json",
        "total_duration": 30.0, 
        "model": {
            "type": "whisper",
            "size": "base"
        },
        "segments": [
            {
                "speaker": "SPEAKER_0",  # Actually interviewer
                "start_time": 1.0,
                "end_time": 2.0,
                "duration": 1.0,
                "text": "Ready?",
                "language": "en",
                "confidence": None,
                "words": []
            },
            {
                "speaker": "SPEAKER_1",  # Actually candidate
                "start_time": 3.0,
                "end_time": 4.0,
                "duration": 1.0,
                "text": "Yes.",
                "language": "en",
                "confidence": None,
                "words": []
            },
            {
                "speaker": "SPEAKER_0",  # Actually interviewer
                "start_time": 5.0,
                "end_time": 7.0,
                "duration": 2.0,
                "text": "What about React?",
                "language": "en",
                "confidence": None,
                "words": []
            },
            {
                "speaker": "SPEAKER_1",  # Actually candidate
                "start_time": 8.0,
                "end_time": 10.0,
                "duration": 2.0,
                "text": "I know React well.",
                "language": "en",
                "confidence": None,
                "words": []
            }
        ]
    }
    return test_data

def test_ollama_availability():
    """Test if Ollama is available."""
    print("🔍 Testing Ollama availability...")
    ollama = OllamaClient()
    
    if ollama.is_available():
        print("✅ Ollama is available with qwen2.5:3b-instruct")
        return True
    else:
        print("❌ Ollama not available")
        print("   Ensure Ollama is running: ollama serve")
        print("   Install model: ollama pull qwen2.5:3b-instruct")
        return False

def run_test_case(test_name: str, test_data: dict, output_dir: str):
    """Run a single test case."""
    print(f"\n🧪 Running test case: {test_name}")
    print(f"   Segments: {len(test_data['segments'])}")
    
    # Create temporary test file
    test_file = Path(output_dir) / f"test_{test_name.lower().replace(' ', '_')}_transcript.json"
    
    with open(test_file, 'w') as f:
        json.dump(test_data, f, indent=2)
    
    try:
        # Run Phase 4 processing
        result = process(str(test_file), output_dir)
        
        print(f"✅ {test_name} completed successfully!")
        print(f"   Corrected transcript: {result['corrected_transcript_path']}")
        print(f"   Q/A pairs: {len(result['qa_pairs'])}")
        print(f"   Speaker corrections: {result['statistics']['speaker_corrections']}")
        
        # Verify speaker corrections occurred
        if result['statistics']['speaker_corrections'] > 0:
            print(f"   ✅ Speaker corrections detected: {result['statistics']['speaker_corrections']}")
        else:
            print(f"   ⚠️  No speaker corrections made")
        
        # Verify Q/A pairs found
        if len(result['qa_pairs']) > 0:
            print(f"   ✅ Q/A pairs found: {len(result['qa_pairs'])}")
            for i, qa in enumerate(result['qa_pairs'][:2]):  # Show first 2
                print(f"      Q{i+1}: {qa['question_text'][:60]}...")
                print(f"      A{i+1}: {qa['answer_text'][:60]}...")
        else:
            print(f"   ⚠️  No Q/A pairs found")
            
        return True
        
    except Exception as e:
        print(f"❌ {test_name} failed: {e}")
        return False

def main():
    """Main test runner."""
    print("🧪 Phase 4 LLM-Based Speaker Correction Test Suite")
    print("=" * 50)
    
    # Create test output directory
    test_output_dir = Path("data/intermediate/phase_04/test")
    test_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Test 1: Check Ollama availability
    ollama_available = test_ollama_availability()
    
    if not ollama_available:
        print("\n⚠️  Proceeding with fallback mode (LLM unavailable)")
        print("   Note: Results will use rule-based correction instead of LLM")
    
    # Test 2: Mislabeled speakers
    mislabeled_data = create_mislabeled_test_data()
    success1 = run_test_case("Mislabeled Speakers", mislabeled_data, str(test_output_dir))
    
    # Test 3: Short dialogue
    short_dialogue_data = create_short_dialogue_test()
    success2 = run_test_case("Short Dialogue", short_dialogue_data, str(test_output_dir))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Test Summary:")
    print(f"   Mislabeled speakers test: {'✅ PASS' if success1 else '❌ FAIL'}")
    print(f"   Short dialogue test: {'✅ PASS' if success2 else '❌ FAIL'}")
    
    if success1 and success2:
        print("🎉 All tests passed!")
        sys.exit(0)
    else:
        print("❌ Some tests failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()