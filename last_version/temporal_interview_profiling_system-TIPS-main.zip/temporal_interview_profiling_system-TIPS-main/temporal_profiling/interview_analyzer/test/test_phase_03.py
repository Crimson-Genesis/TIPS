#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'phases', 'phase_03_transcription'))

from process import process, get_speaker_transcripts, export_plain_text, export_srt

if __name__ == "__main__":
    # Default to Phase 1+2 outputs if no args provided
    if len(sys.argv) != 3:
        audio_path = "./data/intermediate/phase_01/test_video/test_video.wav"
        diarization_path = "./data/intermediate/phase_02/test_video/test_video_diarization.json"
        print(f"Using default paths:")
        print(f"Audio: {audio_path}")
        print(f"Diarization: {diarization_path}")
        print()
    else:
        audio_path = sys.argv[1]
        diarization_path = sys.argv[2]
    
    try:
        print("Starting Phase 3 transcription...")
        print(f"Audio: {audio_path}")
        print(f"Diarization: {diarization_path}")
        print()
        
        result = process(audio_path, diarization_path)
        transcript_map = result['transcript_map']
        
        print("Phase 3 transcription completed successfully!")
        print(f"Transcript saved to: {result['transcript_path']}")
        print(f"Total duration: {transcript_map['total_duration']} seconds")
        print(f"Total segments: {transcript_map['statistics']['total_segments']}")
        print(f"Successful transcriptions: {transcript_map['statistics']['successful_transcriptions']}")
        print(f"Failed transcriptions: {transcript_map['statistics']['failed_transcriptions']}")
        print(f"Model used: {transcript_map['model']['type']} ({transcript_map['model']['size']})")
        
        # Show speaker breakdown
        print(f"\nSpeaker breakdown:")
        for speaker, count in transcript_map['statistics']['language_distribution'].items():
            print(f"  {speaker}: {count} segments")
        
        # Get speaker transcripts
        speaker_transcripts = get_speaker_transcripts(transcript_map)
        print(f"\nSpeaker transcript counts:")
        for speaker, segments in speaker_transcripts.items():
            print(f"  {speaker}: {len(segments)} segments")
        
        # Show first few transcript segments
        print("\nFirst few transcribed segments:")
        for i, segment in enumerate(transcript_map['segments'][:5]):
            print(f"  {segment['speaker']}: {segment['start_time']:.2f}s - {segment['end_time']:.2f}s")
            print(f"    Text: {segment['text']}")
            print(f"    Language: {segment['language']}")
            print()
        
        # Export to plain text
        plain_text_path = os.path.join(os.path.dirname(result['transcript_path']), "transcript.txt")
        export_plain_text(transcript_map, plain_text_path)
        print(f"Plain text exported to: {plain_text_path}")
        
        # Export to SRT
        srt_path = os.path.join(os.path.dirname(result['transcript_path']), "transcript.srt")
        export_srt(transcript_map, srt_path)
        print(f"SRT exported to: {srt_path}")
            
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)