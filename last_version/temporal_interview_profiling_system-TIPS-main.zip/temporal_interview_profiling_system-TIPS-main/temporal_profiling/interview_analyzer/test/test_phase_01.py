#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'phases', 'phase_01_ingestion'))

from process import process

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python test_phase_01.py <video_path>")
        sys.exit(1)
    
    video_path = sys.argv[1]
    try:
        result = process(video_path)
        print("Phase 1 processing completed successfully!")
        print(f"Audio saved to: {result['audio_path']}")
        print(f"Metadata saved to: {result['metadata_path']}")
        print(f"Video duration: {result['metadata']['duration']} seconds")
        print(f"Video resolution: {result['metadata']['video']['width']}x{result['metadata']['video']['height']}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)