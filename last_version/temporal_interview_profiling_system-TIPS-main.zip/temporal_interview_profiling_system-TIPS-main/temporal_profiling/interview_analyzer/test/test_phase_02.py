#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'phases', 'phase_02_diarization'))

from process import process, get_speaker_mapping

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python test_phase_02.py <audio_path>")
        sys.exit(1)
    
    audio_path = sys.argv[1]
    try:
        result = process(audio_path)
        diarization_map = result['diarization_map']
        
        print("Phase 2 diarization completed successfully!")
        print(f"Diarization saved to: {result['diarization_path']}")
        print(f"Total duration: {diarization_map['total_duration']} seconds")
        print(f"Total segments: {diarization_map['statistics']['total_segments']}")
        print(f"Speakers detected: {diarization_map['statistics']['speakers']}")
        
        # Get speaker mapping
        speaker_mapping = get_speaker_mapping(diarization_map)
        print(f"Suggested mapping:")
        print(f"  Interviewer: {speaker_mapping['interviewer']}")
        print(f"  Candidate: {speaker_mapping['candidate']}")
        
        # Show first few segments
        print("\nFirst few segments:")
        for i, segment in enumerate(diarization_map['segments'][:5]):
            print(f"  {segment['speaker']}: {segment['start_time']:.2f}s - {segment['end_time']:.2f}s ({segment['duration']:.2f}s)")
            
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)