#!/usr/bin/env python3

import sys
import os
import json
from pathlib import Path

# Add Phase 5 to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'phases', 'phase_05_feature_extraction'))

def create_test_qa_mapping():
    """Create test Q/A mapping data."""
    return {
        "metadata": {
            "phase": 4,
            "description": "Question-Answer Mapping",
            "mapping_method": "deterministic",
            "total_qa_pairs": 3
        },
        "qa_pairs": [
            {
                "question_id": "q_1",
                "question_text": "Can you tell me about your experience with system design?",
                "question_start_time": 5.0,
                "answer_text": "I have worked on several large-scale systems including distributed databases and microservices architectures.",
                "answer_start_time": 10.0,
                "answer_end_time": 15.0,
                "linked_segment_ids": ["seg_0", "seg_1"]
            },
            {
                "question_id": "q_2", 
                "question_text": "What about React?",
                "question_start_time": 20.0,
                "answer_text": "I know React well.",
                "answer_start_time": 25.0,
                "answer_end_time": 26.0,
                "linked_segment_ids": ["seg_2", "seg_3"]
            },
            {
                "question_id": "q_3",
                "question_text": "How do you handle scalability?",
                "question_start_time": 30.0,
                "answer_text": "",
                "answer_start_time": 0,
                "answer_end_time": 0,
                "linked_segment_ids": ["seg_4"]
            }
        ]
    }

def create_test_corrected_transcript():
    """Create test corrected transcript data."""
    return {
        "metadata": {
            "phase": 4,
            "description": "Speaker Attribution Correction + Q/A Mapping",
            "total_segments": 5
        },
        "segments": [
            {
                "segment_id": "seg_0",
                "text": "Can you tell me about your experience with system design?",
                "start_time": 5.0,
                "end_time": 6.0,
                "original_speaker_label": "SPEAKER_0",
                "corrected_speaker_label": "interviewer",
                "segment_type": "question",
                "confidence": "high"
            },
            {
                "segment_id": "seg_1",
                "text": "I have worked on several large-scale systems including distributed databases and microservices architectures.",
                "start_time": 10.0,
                "end_time": 15.0,
                "original_speaker_label": "SPEAKER_1",
                "corrected_speaker_label": "candidate",
                "segment_type": "answer",
                "confidence": "high"
            },
            {
                "segment_id": "seg_2",
                "text": "What about React?",
                "start_time": 20.0,
                "end_time": 21.0,
                "original_speaker_label": "SPEAKER_0",
                "corrected_speaker_label": "interviewer",
                "segment_type": "question",
                "confidence": "high"
            },
            {
                "segment_id": "seg_3",
                "text": "I know React well.",
                "start_time": 25.0,
                "end_time": 26.0,
                "original_speaker_label": "SPEAKER_1",
                "corrected_speaker_label": "candidate",
                "segment_type": "answer",
                "confidence": "high"
            },
            {
                "segment_id": "seg_4",
                "text": "Um, okay, next question.",
                "start_time": 30.0,
                "end_time": 32.0,
                "original_speaker_label": "SPEAKER_0",
                "corrected_speaker_label": "interviewer",
                "segment_type": "question",
                "confidence": "high"
            }
        ]
    }

def test_fixed_input_output():
    """Test that identical input produces identical output."""
    from process import process
    
    print("🧪 Phase 5 Test: Fixed Input → Identical Output")
    
    # Create test data
    qa_mapping = create_test_qa_mapping()
    corrected_transcript = create_test_corrected_transcript()
    
    # Create temporary test files
    test_dir = Path("data/intermediate/phase_05/test")
    test_dir.mkdir(parents=True, exist_ok=True)
    
    qa_file = test_dir / "test_qa_mapping.json"
    transcript_file = test_dir / "test_corrected_transcript.json"
    
    with open(qa_file, 'w') as f:
        json.dump(qa_mapping, f, indent=2)
    
    with open(transcript_file, 'w') as f:
        json.dump(corrected_transcript, f, indent=2)
    
    print(f"📁 Created test files: {qa_file}, {transcript_file}")
    
    try:
        # Run Phase 5
        result1 = process(str(qa_file), str(transcript_file))
        result2 = process(str(qa_file), str(transcript_file))
        
        # Load results
        with open(result1['features_path'], 'r') as f:
            output1 = json.load(f)
        
        with open(result2['features_path'], 'r') as f:
            output2 = json.load(f)
        
        # Compare key features (ignore timestamps)
        features1 = output1['answers']
        features2 = output2['answers']
        
        identical = True
        for i, (f1, f2) in enumerate(zip(features1, features2)):
            for key in ['word_count', 'filler_word_count', 'lexical_diversity', 'complexity_score']:
                if f1.get(key) != f2.get(key):
                    print(f"❌ Mismatch at answer {i}: {key} = {f1.get(key)} vs {f2.get(key)}")
                    identical = False
        
        if identical:
            print("✅ Test PASSED: Identical input produces identical output")
            return True
        else:
            print("❌ Test FAILED: Identical input produces different output")
            return False
            
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_empty_answers():
    """Test handling of empty answers."""
    from process import process
    
    print("🧪 Phase 5 Test: Empty Answer Handling")
    
    # Create test data with empty answer
    qa_mapping = {
        "metadata": {"phase": 4, "total_qa_pairs": 1},
        "qa_pairs": [
            {
                "question_id": "q_empty",
                "question_text": "Can you explain this?",
                "question_start_time": 1.0,
                "answer_text": "",
                "answer_start_time": 0,
                "answer_end_time": 0,
                "linked_segment_ids": ["seg_1"]
            }
        ]
    }
    
    corrected_transcript = {
        "metadata": {"phase": 4, "total_segments": 2},
        "segments": []
    }
    
    test_dir = Path("data/intermediate/phase_05/test")
    qa_file = test_dir / "test_empty_qa.json"
    transcript_file = test_dir / "test_empty_transcript.json"
    
    with open(qa_file, 'w') as f:
        json.dump(qa_mapping, f, indent=2)
    
    with open(transcript_file, 'w') as f:
        json.dump(corrected_transcript, f, indent=2)
    
    try:
        result = process(str(qa_file), str(transcript_file))
        
        with open(result['features_path'], 'r') as f:
            output = json.load(f)
        
        # Check empty answer handling
        answer_features = output.get('answers', [])
        
        if len(answer_features) == 1:
            answer = answer_features[0]
            if (answer.get('word_count') == 0 and 
                answer.get('speaking_duration') == 0 and
                answer.get('speech_rate') == 0.0):
                print("✅ Test PASSED: Empty answer handled correctly")
                return True
            else:
                print(f"❌ Test FAILED: Empty answer has incorrect features: {answer}")
                return False
        else:
            print("❌ Test FAILED: Expected 1 answer feature, got", len(answer_features))
            return False
            
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_short_long_answers():
    """Test short vs long answer handling."""
    from process import process
    
    print("🧪 Phase 5 Test: Short vs Long Answers")
    
    # Test data with varying answer lengths
    qa_mapping = {
        "metadata": {"phase": 4, "total_qa_pairs": 2},
        "qa_pairs": [
            {
                "question_id": "q_short",
                "question_text": "What is React?",
                "question_start_time": 1.0,
                "answer_text": "I know React.",
                "answer_start_time": 5.0,
                "answer_end_time": 6.0,
                "linked_segment_ids": ["seg_1"]
            },
            {
                "question_id": "q_long", 
                "question_text": "Explain your system design experience?",
                "question_start_time": 10.0,
                "answer_text": "I have worked extensively on system design, creating distributed architectures, implementing microservices patterns, utilizing containerization technologies, developing scalable solutions that handle millions of requests while maintaining high availability and fault tolerance through careful load balancing and database sharding strategies.",
                "answer_start_time": 15.0,
                "answer_end_time": 25.0,
                "linked_segment_ids": ["seg_2", "seg_3"]
            }
        ]
    }
    
    corrected_transcript = {"metadata": {"phase": 4, "total_segments": 4}, "segments": []}
    
    test_dir = Path("data/intermediate/phase_05/test")
    qa_file = test_dir / "test_length_qa.json"
    transcript_file = test_dir / "test_length_transcript.json"
    
    with open(qa_file, 'w') as f:
        json.dump(qa_mapping, f, indent=2)
    
    with open(transcript_file, 'w') as f:
        json.dump(corrected_transcript, f, indent=2)
    
    try:
        result = process(str(qa_file), str(transcript_file))
        
        with open(result['features_path'], 'r') as f:
            output = json.load(f)
        
        answer_features = output.get('answers', [])
        
        if len(answer_features) == 2:
            short_answer = answer_features[0]
            long_answer = answer_features[1]
            
            # Validate short answer
            if (short_answer.get('word_count') == 3 and 
                short_answer.get('speaking_duration') == 1.0 and
                short_answer.get('speech_rate') == 3.0):
                print("✅ Short answer features correct")
                short_ok = True
            else:
                print(f"❌ Short answer wrong: {short_answer}")
                short_ok = False
            
            # Validate long answer  
            if (long_answer.get('word_count') > 30 and 
                long_answer.get('speaking_duration') == 10.0 and
                long_answer.get('complexity_score') > 5.0):
                print("✅ Long answer features correct")
                long_ok = True
            else:
                print(f"❌ Long answer wrong: {long_answer}")
                long_ok = False
            
            return short_ok and long_ok
        else:
            print("❌ Expected 2 answer features, got", len(answer_features))
            return False
            
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def main():
    """Run all Phase 5 tests."""
    print("🧪 Phase 5 Deterministic Feature Extraction Test Suite")
    print("=" * 50)
    
    # Create test directory
    test_dir = Path("data/intermediate/phase_05/test")
    test_dir.mkdir(parents=True, exist_ok=True)
    
    # Run tests
    tests = [
        ("Fixed Input/Output", test_fixed_input_output),
        ("Empty Answer Handling", test_empty_answers), 
        ("Short/Long Answer Handling", test_short_long_answers)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n🧪 Running: {test_name}")
        result = test_func()
        results.append((test_name, result))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Test Summary:")
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {test_name}: {status}")
        if result:
            passed += 1
    
    print(f"\n🎯 Tests passed: {passed}/{len(tests)}")
    
    if passed == len(tests):
        print("🎉 All tests passed!")
        return True
    else:
        print("❌ Some tests failed!")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)