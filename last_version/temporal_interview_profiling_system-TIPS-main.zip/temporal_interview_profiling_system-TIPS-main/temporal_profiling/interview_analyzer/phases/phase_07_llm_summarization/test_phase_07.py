#!/usr/bin/env python3

import sys
import os
import json
from pathlib import Path

# Add Phase 7 to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'phases', 'phase_07_llm_summarization'))

def create_test_profile_v1():
    """Create test profile data for v1 - strong fit candidate."""
    return {
        "profile_version": 1,
        "processed_question_ids": ["q_1"],
        "aggregated_metrics": {
            "total_questions_processed": 1,
            "total_valid_answers": 1,
            "total_empty_answers": 0,
            "cumulative_word_count": 25,
            "cumulative_speaking_duration": 5.0,
            "average_speech_rate": 5.0,
            "cumulative_filler_word_count": 1,
            "average_filler_ratio": 0.04,
            "average_complexity_score": 8.5,
            "average_pause_duration": 1.5
        },
        "per_answer_records": [
            {
                "question_id": "q_1",
                "question_text": "Design a scalable URL shortener service.",
                "answer_text": "I'll design a URL shortener using a distributed architecture with load balancing, database sharding, and CDN integration. The system will handle billions of URLs with millisecond latency.",
                "features": {
                    "word_count": 25,
                    "speech_rate": 5.0,
                    "filler_word_count": 1,
                    "filler_word_ratio": 0.04,
                    "complexity_score": 8.5,
                    "pause_duration_before_answer": 1.5
                }
            }
        ]
    }

def create_test_profile_v2():
    """Create test profile data for v2 - evolving candidate."""
    return {
        "profile_version": 2,
        "processed_question_ids": ["q_1", "q_2"],
        "aggregated_metrics": {
            "total_questions_processed": 2,
            "total_valid_answers": 2,
            "total_empty_answers": 0,
            "cumulative_word_count": 40,
            "cumulative_speaking_duration": 8.0,
            "average_speech_rate": 5.0,
            "cumulative_filler_word_count": 2,
            "average_filler_ratio": 0.05,
            "average_complexity_score": 8.2,
            "average_pause_duration": 2.0
        },
        "per_answer_records": [
            {
                "question_id": "q_1",
                "question_text": "Design a scalable URL shortener service.",
                "answer_text": "I'll design a URL shortener using a distributed architecture with load balancing, database sharding, and CDN integration.",
                "features": {
                    "word_count": 25,
                    "speech_rate": 5.0,
                    "filler_word_count": 1,
                    "filler_word_ratio": 0.04,
                    "complexity_score": 8.5,
                    "pause_duration_before_answer": 1.5
                }
            },
            {
                "question_id": "q_2",
                "question_text": "How would you handle database failures?",
                "answer_text": "I'll implement master-slave replication with automatic failover, consistent hashing for sharding, and write-ahead logging for durability.",
                "features": {
                    "word_count": 15,
                    "speech_rate": 5.0,
                    "filler_word_count": 1,
                    "filler_word_ratio": 0.067,
                    "complexity_score": 8.0,
                    "pause_duration_before_answer": 2.5
                }
            }
        ]
    }

def create_test_profile_weak_fit():
    """Create test profile data for weak fit candidate."""
    return {
        "profile_version": 1,
        "processed_question_ids": ["q_1"],
        "aggregated_metrics": {
            "total_questions_processed": 1,
            "total_valid_answers": 1,
            "total_empty_answers": 0,
            "cumulative_word_count": 8,
            "cumulative_speaking_duration": 8.0,
            "average_speech_rate": 1.0,
            "cumulative_filler_word_count": 4,
            "average_filler_ratio": 0.5,
            "average_complexity_score": 3.0,
            "average_pause_duration": 5.0
        },
        "per_answer_records": [
            {
                "question_id": "q_1",
                "question_text": "Design a scalable system.",
                "answer_text": "Um, I guess I would use, like, some servers and stuff. Maybe a database?",
                "features": {
                    "word_count": 8,
                    "speech_rate": 1.0,
                    "filler_word_count": 4,
                    "filler_word_ratio": 0.5,
                    "complexity_score": 3.0,
                    "pause_duration_before_answer": 5.0
                }
            }
        ]
    }

def create_test_qa_mapping():
    """Create test Q/A mapping data."""
    return {
        "metadata": {
            "phase": 4,
            "description": "Question-Answer Mapping",
            "total_qa_pairs": 2
        },
        "qa_pairs": [
            {
                "question_id": "q_1",
                "question_text": "Design a scalable URL shortener service.",
                "answer_text": "I'll design a URL shortener using a distributed architecture with load balancing, database sharding, and CDN integration."
            },
            {
                "question_id": "q_2",
                "question_text": "How would you handle database failures?",
                "answer_text": "I'll implement master-slave replication with automatic failover, consistent hashing for sharding, and write-ahead logging for durability."
            }
        ]
    }

def create_test_jd_system_design():
    """Create JD for System Design Engineer role."""
    return """**Job Title:** System Design Engineer

**Role Overview:**
Responsible for designing scalable, reliable, and maintainable systems. This role focuses purely on system architecture and design decisions.

**Responsibilities:**
* Define system requirements from vague or high-level problem statements.
* Design end-to-end system architectures for large-scale applications.
* Make clear trade-offs between performance, scalability, consistency, availability, and cost.
* Design APIs, data models, storage strategies, caching layers, and communication patterns.
* Handle failure scenarios, bottlenecks, and capacity planning.

**Required Skills:**
* Strong understanding of distributed systems fundamentals.
* Experience with scalability patterns (sharding, replication, load balancing).
* Knowledge of databases (SQL, NoSQL), caching systems, and messaging queues.
* Ability to reason about latency, throughput, and fault tolerance.
* Clear architectural thinking and communication.

**Nice to Have:**
* Experience designing systems at internet scale.
* Familiarity with cloud infrastructure and CDNs.
"""

def create_test_jd_frontend_dev():
    """Create JD for Frontend Developer role (mismatch)."""
    return """**Job Title:** Frontend Developer

**Role Overview:**
Responsible for building user interfaces and web applications using modern JavaScript frameworks.

**Responsibilities:**
* Develop responsive web applications using React, Vue, or Angular.
* Create interactive user interfaces with CSS and JavaScript.
* Implement state management and component-based architecture.
* Work with RESTful APIs and handle async data flows.
* Optimize applications for performance and accessibility.

**Required Skills:**
* Strong proficiency in JavaScript, HTML5, CSS3.
* Experience with modern frontend frameworks (React, Vue, Angular).
* Knowledge of responsive design and cross-browser compatibility.
* Understanding of web performance optimization techniques.
* Familiarity with build tools and version control.

**Nice to Have:**
* Experience with TypeScript.
* Knowledge of testing frameworks.
* Understanding of UX/UI principles.
"""

def test_llm_availability():
    """Test LLM availability detection."""
    from process import OllamaJobFitEvaluator
    
    print("🤖 Phase 7 Test: LLM Availability Detection")
    
    try:
        evaluator = OllamaJobFitEvaluator()
        is_available = evaluator.is_available()
        
        if isinstance(is_available, bool):
            print("✅ Test PASSED: LLM availability detection works")
            print(f"   LLM available: {is_available}")
            return True
        else:
            print(f"❌ Test FAILED: Expected boolean, got {type(is_available)}")
            return False
            
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_jd_loading():
    """Test JD file loading."""
    from process import IncrementalJobFitEvaluator
    
    print("🤖 Phase 7 Test: JD File Loading")
    
    try:
        evaluator = IncrementalJobFitEvaluator()
        
        # Test valid JD
        jd_text = evaluator.load_jd(create_test_jd_system_design())
        if jd_text and len(jd_text) > 0:
            print("✅ JD string loading: PASSED")
        else:
            print("❌ JD string loading: FAILED")
            return False
        
        # Create temporary JD file
        test_dir = Path("data/final/test_phase7")
        test_dir.mkdir(parents=True, exist_ok=True)
        
        jd_file = test_dir / "test_jd.txt"
        with open(jd_file, 'w') as f:
            f.write(create_test_jd_system_design())
        
        jd_text_from_file = evaluator.load_jd(str(jd_file))
        if jd_text_from_file and len(jd_text_from_file) > 0:
            print("✅ JD file loading: PASSED")
            return True
        else:
            print("❌ JD file loading: FAILED")
            return False
            
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_strong_fit_evaluation():
    """Test job fit evaluation for strong fit candidate."""
    from process import IncrementalJobFitEvaluator
    
    print("🤖 Phase 7 Test: Strong Fit Evaluation")
    
    try:
        evaluator = IncrementalJobFitEvaluator()
        
        profile_data = create_test_profile_v1()
        qa_mapping = create_test_qa_mapping()
        jd_text = create_test_jd_system_design()
        
        evaluation = evaluator.evaluator.generate_job_fit_evaluation(profile_data, qa_mapping, jd_text)
        
        if evaluation.get('job_fit_assessment', {}).get('fit_status') == 'strong_fit':
            print("✅ Test PASSED: Strong fit candidate correctly identified")
            print(f"   Fit status: {evaluation.get('job_fit_assessment', {}).get('fit_status')}")
            return True
        else:
            print(f"❌ Test FAILED: Expected strong_fit, got {evaluation.get('job_fit_assessment', {}).get('fit_status')}")
            print(f"   Evaluation: {evaluation}")
            return False
            
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_weak_fit_evaluation():
    """Test job fit evaluation for weak fit candidate."""
    from process import IncrementalJobFitEvaluator
    
    print("🤖 Phase 7 Test: Weak Fit Evaluation")
    
    try:
        evaluator = IncrementalJobFitEvaluator()
        
        profile_data = create_test_profile_weak_fit()
        qa_mapping = create_test_qa_mapping()
        jd_text = create_test_jd_system_design()
        
        evaluation = evaluator.evaluator.generate_job_fit_evaluation(profile_data, qa_mapping, jd_text)
        
        if evaluation.get('job_fit_assessment', {}).get('fit_status') == 'weak_fit':
            print("✅ Test PASSED: Weak fit candidate correctly identified")
            print(f"   Fit status: {evaluation.get('job_fit_assessment', {}).get('fit_status')}")
            return True
        else:
            print(f"❌ Test FAILED: Expected weak_fit, got {evaluation.get('job_fit_assessment', {}).get('fit_status')}")
            return False
            
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_role_mismatch_evaluation():
    """Test job fit evaluation for role mismatch."""
    from process import IncrementalJobFitEvaluator
    
    print("🤖 Phase 7 Test: Role Mismatch Evaluation")
    
    try:
        evaluator = IncrementalJobFitEvaluator()
        
        # System design candidate but frontend job
        profile_data = create_test_profile_v1()
        qa_mapping = create_test_qa_mapping()
        jd_text = create_test_jd_frontend_dev()
        
        evaluation = evaluator.evaluator.generate_job_fit_evaluation(profile_data, qa_mapping, jd_text)
        
        fit_status = evaluation.get('job_fit_assessment', {}).get('fit_status')
        if fit_status in ['weak_fit', 'partial_fit']:
            print("✅ Test PASSED: Role mismatch correctly identified")
            print(f"   Fit status: {fit_status}")
            return True
        else:
            print(f"❌ Test FAILED: Expected weak/partial fit for role mismatch, got {fit_status}")
            return False
            
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_incremental_job_fit_evaluations():
    """Test incremental job fit evaluation generation."""
    from process import IncrementalJobFitEvaluator
    
    print("🤖 Phase 7 Test: Incremental Job Fit Evaluations")
    
    try:
        evaluator = IncrementalJobFitEvaluator()
        
        profile_v1 = create_test_profile_v1()
        profile_v2 = create_test_profile_v2()
        profiles = [profile_v1, profile_v2]
        
        qa_mapping = create_test_qa_mapping()
        jd_text = create_test_jd_system_design()
        
        evaluations = evaluator.create_incremental_evaluations(profiles, qa_mapping, jd_text)
        
        if len(evaluations) != 2:
            print(f"❌ Expected 2 evaluations, got {len(evaluations)}")
            return False
        
        # Check v1 evaluation
        eval_v1 = evaluations[0]
        if (eval_v1['evaluation_version'] != 1 or
            eval_v1['profile_version'] != 1):
            print(f"❌ Evaluation v1 version info incorrect: {eval_v1}")
            return False
        
        # Check v2 evaluation
        eval_v2 = evaluations[1]
        if (eval_v2['evaluation_version'] != 2 or
            eval_v2['profile_version'] != 2):
            print(f"❌ Evaluation v2 version info incorrect: {eval_v2}")
            return False
        
        # Check that evaluations have required fields
        required_fields = ['summary_text', 'reasoning_points', 'job_fit_assessment', 'timestamp']
        for evaluation in evaluations:
            for field in required_fields:
                if not evaluation.get(field):
                    print(f"❌ Missing required field '{field}' in evaluation")
                    return False
        
        print("✅ Test PASSED: Incremental job fit evaluation generation")
        return True
        
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_final_consolidated_evaluation():
    """Test final consolidated evaluation creation."""
    from process import IncrementalJobFitEvaluator
    
    print("🤖 Phase 7 Test: Final Consolidated Evaluation")
    
    try:
        evaluator = IncrementalJobFitEvaluator()
        
        # Create test evaluations
        evaluations = [
            {
                "evaluation_version": 1,
                "summary_text": "Initial response shows good system design thinking.",
                "job_fit_assessment": {
                    "fit_status": "partial_fit",
                    "matching_requirements": ["System design"],
                    "missing_or_weak_areas": ["Scalability details"]
                },
                "timestamp": "2026-02-02T05:30:00.000000"
            },
            {
                "evaluation_version": 2,
                "summary_text": "Candidate demonstrates strong system design expertise.",
                "job_fit_assessment": {
                    "fit_status": "strong_fit",
                    "matching_requirements": ["System design", "Scalability", "Distributed systems"],
                    "missing_or_weak_areas": []
                },
                "timestamp": "2026-02-02T05:31:00.000000"
            }
        ]
        
        consolidated = evaluator.create_final_consolidated_evaluation(evaluations, "test JD")
        
        # Check structure
        if not consolidated.get('metadata'):
            print("❌ Missing metadata in consolidated evaluation")
            return False
        
        if not consolidated.get('final_evaluation'):
            print("❌ Missing final_evaluation in consolidated evaluation")
            return False
        
        if not consolidated.get('evaluation_progression'):
            print("❌ Missing evaluation_progression in consolidated evaluation")
            return False
        
        # Check trend analysis
        trend_analysis = consolidated.get('fit_trend_analysis', {})
        if trend_analysis.get('trend') == 'improving':
            print("✅ Trend analysis correctly identified improvement")
        else:
            print(f"❌ Expected 'improving' trend, got {trend_analysis.get('trend')}")
            return False
        
        print("✅ Test PASSED: Final consolidated evaluation")
        return True
        
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_early_interview_handling():
    """Test handling of early interview termination (few answers)."""
    from process import IncrementalJobFitEvaluator
    
    print("🤖 Phase 7 Test: Early Interview Handling")
    
    try:
        evaluator = IncrementalJobFitEvaluator()
        
        # Create profile with only 1 question and weak answer
        early_profile = {
            "profile_version": 1,
            "processed_question_ids": ["q_1"],
            "aggregated_metrics": {
                "total_questions_processed": 1,
                "total_valid_answers": 0,
                "total_empty_answers": 1,
                "cumulative_word_count": 0,
                "cumulative_speaking_duration": 0,
                "average_speech_rate": 0,
                "cumulative_filler_word_count": 0,
                "average_filler_ratio": 0,
                "average_complexity_score": 0,
                "average_pause_duration": 0
            },
            "per_answer_records": [
                {
                    "question_id": "q_1",
                    "question_text": "Can you start?",
                    "answer_text": "",
                    "features": {
                        "word_count": 0,
                        "speech_rate": 0,
                        "filler_word_count": 0,
                        "filler_word_ratio": 0,
                        "complexity_score": 0,
                        "pause_duration_before_answer": 0
                    }
                }
            ]
        }
        
        qa_mapping = create_test_qa_mapping()
        jd_text = create_test_jd_system_design()
        
        evaluation = evaluator.evaluator.generate_job_fit_evaluation(early_profile, qa_mapping, jd_text)
        
        fit_status = evaluation.get('job_fit_assessment', {}).get('fit_status', 'weak_fit')
        if fit_status == 'weak_fit':
            print("✅ Test PASSED: Early interview handled appropriately")
            print(f"   Fit status: {fit_status}")
            return True
        else:
            print(f"❌ Test FAILED: Expected weak_fit for early interview, got {fit_status}")
            return False
            
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def main():
    """Run all Phase 7 tests."""
    print("🤖 Phase 7 LLM-Based Reasoning, Summarization, and Job-Fit Evaluation Test Suite")
    print("=" * 80)
    
    # Create test directory
    test_dir = Path("data/final/test_phase7")
    test_dir.mkdir(parents=True, exist_ok=True)
    
    # Run tests
    tests = [
        ("LLM Availability Detection", test_llm_availability),
        ("JD File Loading", test_jd_loading),
        ("Strong Fit Evaluation", test_strong_fit_evaluation),
        ("Weak Fit Evaluation", test_weak_fit_evaluation),
        ("Role Mismatch Evaluation", test_role_mismatch_evaluation),
        ("Incremental Job Fit Evaluations", test_incremental_job_fit_evaluations),
        ("Final Consolidated Evaluation", test_final_consolidated_evaluation),
        ("Early Interview Handling", test_early_interview_handling)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n🤖 Running: {test_name}")
        result = test_func()
        results.append((test_name, result))
    
    # Summary
    print("\n" + "=" * 80)
    print("📊 Test Summary:")
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {test_name}: {status}")
        if result:
            passed += 1
    
    print(f"\n🎯 Tests passed: {passed}/{len(tests)}")
    
    if passed == len(tests):
        print("🎉 All tests passed!")
        return True
    else:
        print("❌ Some tests failed!")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)