import json
import requests
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import copy


class OllamaJobFitEvaluator:
    """Local Ollama client for qwen2.5:3b-instruct with job fit evaluation."""
    
    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url
        self.model = "qwen2.5:3b-instruct"
        self.fallback_mode = False
    
    def _format_recent_qa(self, records: List[Dict]) -> str:
        """Format recent Q&A for prompt."""
        qa_text = ""
        valid_records = [r for r in records if r.get('features', {}).get('word_count', 0) > 0]
        
        for i, record in enumerate(valid_records[-3:], 1):
            q_text = record.get('question_text', '')[:80]
            a_text = record.get('answer_text', '')[:120]
            qa_text += f"Q{i}: {q_text}\nA{i}: {a_text}\n"
        
        return qa_text
    
    def is_available(self) -> bool:
        """Check if Ollama is running and model is available."""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get("models", [])
                return any(model.get("name", "").startswith("qwen2.5:3b") for model in models)
        except Exception:
            pass
        return False
    
    def generate_job_fit_evaluation(self, profile_data: Dict, qa_mapping: Dict, jd_text: str, prior_evaluation: Optional[Dict] = None) -> Dict:
        """
        Generate LLM-based summary and job fit evaluation for a given profile version.
        """
        if not self.is_available():
            self.fallback_mode = True
            return self._fallback_evaluation(profile_data, qa_mapping, jd_text, prior_evaluation)
        
        # Create structured prompt
        prompt = self._create_job_fit_prompt(profile_data, qa_mapping, jd_text, prior_evaluation)
        
        try:
            response = self._call_ollama(prompt)
            evaluation = self._parse_llm_response(response)
            return evaluation
        except Exception as e:
            print(f"⚠️  LLM job fit evaluation failed: {e}")
            # Retry once with more conservative settings
            try:
                response = self._call_ollama(prompt)
                evaluation = self._parse_llm_response(response)
                return evaluation
            except Exception as retry_e:
                print(f"⚠️  LLM retry failed: {retry_e}")
                return self._failed_evaluation(profile_data, str(retry_e))
    
    def _create_job_fit_prompt(self, profile_data: Dict, qa_mapping: Dict, jd_text: str, prior_evaluation: Optional[Dict] = None) -> str:
        """Create structured prompt for LLM job fit evaluation."""
        
        profile_version = profile_data.get('profile_version', 1)
        
        # Simplified prompt with clear JSON structure requirement
        prompt = f"""You are an interviewer evaluator. Evaluate candidate performance against job requirements.

JOB: {jd_text[:800]}

CANDIDATE DATA:
Profile version: {profile_version}
Recent Q&A:
{self._format_recent_qa(profile_data.get('per_answer_records', []))}

TASK: Create JSON evaluation:
- summary_text: 2-3 sentences
- reasoning_points: 2-4 observations  
- job_fit_assessment: {{fit_status, matching_requirements, missing_or_weak_areas, evidence_answer_ids}}
- confidence_level: high|medium|low

OUTPUT ONLY JSON: {{}}
  "summary_text": "text",
  "reasoning_points": ["observation1", "observation2"],
  "job_fit_assessment": {{
    "fit_status": "strong_fit|partial_fit|weak_fit",
    "matching_requirements": ["req1", "req2"],
    "missing_or_weak_areas": ["gap1", "gap2"],
    "evidence_answer_ids": ["q_1", "q_2"]
  }},
  "confidence_level": "high|medium|low"
}}"""

        return prompt
        
        prompt = f"""You are evaluating a technical interview candidate for a specific job. Analyze their performance against the job requirements.

JOB DESCRIPTION:
{jd_truncated}

CANDIDATE PERFORMANCE DATA:
Profile version: {profile_version}
Recent Q&A:
{self._format_recent_qa(profile_data.get('per_answer_records', []))}

{prior_text}

EVALUATION CRITERIA:
1. Technical skills demonstrated vs. required skills
2. System design thinking and architecture reasoning
3. Communication clarity and confidence
4. Problem-solving approach
5. Areas of strength vs. gaps/weaknesses

JOB FIT ASSESSMENT RULES:
- MUST be evidence-based, reference specific answer IDs
- Explicitly state both "why yes" and "why not" for each requirement
- Absence of evidence = weakness, not assumed competence
- Consider interview stage (early vs. late responses)
- Assess both technical fit and communication fit

CRITICAL: Your entire response must be a single JSON object starting with {{ and ending with }}. No extra text, no markdown, no explanations, no code blocks. Output ONLY the JSON object.

OUTPUT EXACTLY THIS JSON:
{{
  "summary_text": "Professional 2-3 sentence summary of candidate's performance",
  "reasoning_points": [
    "Specific observation based on speech patterns",
    "Technical communication assessment", 
    "Areas of strength or concern"
  ],
  "job_fit_assessment": {{
    "fit_status": "strong_fit|partial_fit|weak_fit",
    "matching_requirements": ["skill1", "skill2"],
    "missing_or_weak_areas": ["area1", "area2"],
    "evidence_answer_ids": ["q_X", "q_Y"]
  }},
  "confidence_level": "high|medium|low"
}}"""

        return prompt
    
    def _call_ollama(self, prompt: str) -> str:
        """Make API call to Ollama."""
        response = requests.post(
            f"{self.base_url}/api/generate",
            json={
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.1,  # Lower for more reliable JSON output
                    "num_predict": 600,   # Shorter responses for reliability
                    "num_ctx": 2048,     # Smaller context for stability
                    "top_k": 10,
                    "repeat_penalty": 1.1
                }
            },
            timeout=120
        )
        response.raise_for_status()
        return response.json().get("response", "")
    
    def _parse_llm_response(self, response: str) -> Dict:
        """Parse LLM JSON response."""
        try:
            # First, try to parse the entire response as JSON
            try:
                evaluation = json.loads(response.strip())
                if isinstance(evaluation, dict):
                    return self._validate_and_fix_evaluation(evaluation)
            except json.JSONDecodeError:
                pass
            
            # If that fails, try to extract JSON from response
            json_match = re.search(r'\{.*?\}', response, re.DOTALL)
            if json_match:
                evaluation = json.loads(json_match.group())
                return self._validate_and_fix_evaluation(evaluation)
            else:
                # If no JSON found, create error evaluation
                raise ValueError("No valid JSON found in LLM response")
            
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in LLM response: {e}")
        except Exception as e:
            raise ValueError(f"Failed to parse LLM response: {e}")
    
    def _validate_and_fix_evaluation(self, evaluation: Dict) -> Dict:
        """Validate and fix evaluation fields."""
        # Validate and fix required fields
        job_fit = evaluation.get('job_fit_assessment', {})
        
        # Validate fit_status
        valid_fit_statuses = ['strong_fit', 'partial_fit', 'weak_fit']
        if job_fit.get('fit_status') not in valid_fit_statuses:
            job_fit['fit_status'] = 'weak_fit'
        
        # Ensure arrays exist
        job_fit['matching_requirements'] = job_fit.get('matching_requirements', [])
        job_fit['missing_or_weak_areas'] = job_fit.get('missing_or_weak_areas', [])
        job_fit['evidence_answer_ids'] = job_fit.get('evidence_answer_ids', [])
        
        # Validate confidence_level
        valid_confidence = ['high', 'medium', 'low']
        if evaluation.get('confidence_level') not in valid_confidence:
            evaluation['confidence_level'] = 'low'
        
        # Ensure other required fields exist
        evaluation['summary_text'] = evaluation.get('summary_text', '')
        evaluation['reasoning_points'] = evaluation.get('reasoning_points', [])
        
        evaluation['job_fit_assessment'] = job_fit
        return evaluation
    
    def _fallback_evaluation(self, profile_data: Dict, qa_mapping: Dict, jd_text: str, prior_evaluation: Optional[Dict] = None) -> Dict:
        """Fallback method when LLM is not available."""
        print("⚠️  Using fallback job fit evaluation (LLM unavailable)")
        
        metrics = profile_data.get('aggregated_metrics', {})
        version = profile_data.get('profile_version', 1)
        valid_answers = metrics.get('total_valid_answers', 0)
        speech_rate = metrics.get('average_speech_rate', 0)
        complexity = metrics.get('average_complexity_score', 0)
        
        # Simple rule-based evaluation
        if valid_answers == 0:
            summary_text = "No valid responses provided for evaluation."
            reasoning_points = ["No speech data available for assessment"]
            fit_status = "weak_fit"
            matching_requirements = []
            missing_areas = ["Technical communication", "Problem demonstration"]
        elif speech_rate < 2.0:
            summary_text = "Candidate speaks slowly with potential confidence issues."
            reasoning_points = ["Low speech rate indicates hesitation", "May need more technical confidence"]
            fit_status = "partial_fit"
            matching_requirements = ["Basic communication"]
            missing_areas = ["Technical articulation", "System design clarity"]
        elif speech_rate > 5.0 and complexity < 6.0:
            summary_text = "Candidate speaks quickly but with limited technical depth."
            reasoning_points = ["High speech rate but low complexity", "May need more detailed explanations"]
            fit_status = "partial_fit"
            matching_requirements = ["Communication skills"]
            missing_areas = ["Technical depth", "Architecture complexity"]
        elif complexity >= 7.0 and speech_rate >= 3.0:
            summary_text = "Candidate demonstrates strong technical communication and reasoning."
            reasoning_points = ["High complexity in responses", "Good speech rate", "Clear technical articulation"]
            fit_status = "strong_fit"
            matching_requirements = ["Technical communication", "System design", "Problem solving"]
            missing_areas = []
        else:
            summary_text = "Candidate shows mixed performance with room for improvement."
            reasoning_points = ["Balanced speech patterns", "Moderate technical depth"]
            fit_status = "partial_fit"
            matching_requirements = ["Communication"]
            missing_areas = ["Technical consistency", "Architecture depth"]
        
        # Get answer IDs from recent responses
        records = profile_data.get('per_answer_records', [])
        evidence_ids = [r.get('question_id') for r in records[-3:] if r.get('features', {}).get('word_count', 0) > 0]
        
        return {
            "summary_text": summary_text,
            "reasoning_points": reasoning_points,
            "job_fit_assessment": {
                "fit_status": fit_status,
                "matching_requirements": matching_requirements,
                "missing_or_weak_areas": missing_areas,
                "evidence_answer_ids": evidence_ids
            },
            "confidence_level": "medium",
            "fallback_mode": True
        }
    
    def _failed_evaluation(self, profile_data: Dict, error_msg: str) -> Dict:
        """Failed evaluation marker."""
        return {
            "summary_text": "Evaluation generation failed due to processing error.",
            "reasoning_points": [f"Processing error: {error_msg}"],
            "job_fit_assessment": {
                "fit_status": "weak_fit",
                "matching_requirements": [],
                "missing_or_weak_areas": ["Evaluation failed"],
                "evidence_answer_ids": []
            },
            "confidence_level": "low",
            "failed": True,
            "error_message": error_msg
        }


class IncrementalJobFitEvaluator:
    """Build incremental job fit evaluations based on candidate profiles and JD."""
    
    def __init__(self):
        self.evaluator = OllamaJobFitEvaluator()
        self.evaluation_schema = {
            "evaluation_version": 0,
            "profile_version": 0,
            "summary_text": "",
            "reasoning_points": [],
            "job_fit_assessment": {
                "fit_status": "weak_fit",
                "matching_requirements": [],
                "missing_or_weak_areas": [],
                "evidence_answer_ids": []
            },
            "timestamp": None,
            "llm_metadata": {
                "model": "qwen2.5:3b-instruct",
                "fallback_mode": False,
                "processing_time": 0.0
            }
        }
    
    def load_jd(self, jd_path: str) -> str:
        """Load job description text."""
        try:
            with open(jd_path, 'r', encoding='utf-8') as f:
                jd_text = f.read().strip()
            
            if not jd_text:
                raise ValueError("Job description file is empty")
            
            return jd_text
            
        except FileNotFoundError:
            raise FileNotFoundError(f"Job description file not found: {jd_path}")
        except Exception as e:
            raise ValueError(f"Failed to read job description: {e}")
    
    def load_profiles(self, profile_dir: str, video_name: str) -> List[Dict]:
        """Load all profile versions from Phase 6."""
        profile_path = Path(profile_dir)
        profiles = []
        
        # Find all profile files for this video
        pattern = f"*{video_name}_profile_v*.json"
        profile_files = sorted(profile_path.glob(pattern), key=lambda x: self._extract_version_number(x))
        
        for profile_file in profile_files:
            try:
                with open(profile_file, 'r') as f:
                    profile_data = json.load(f)
                    profiles.append(profile_data)
            except Exception as e:
                print(f"⚠️  Failed to load profile {profile_file}: {e}")
        
        return profiles
    
    def _extract_version_number(self, filepath: Path) -> int:
        """Extract version number from filename."""
        match = re.search(r'_profile_v(\d+)\.json', filepath.name)
        return int(match.group(1)) if match else 0
    
    def load_qa_mapping(self, qa_mapping_path: str) -> Dict:
        """Load Q/A mapping from Phase 4."""
        try:
            with open(qa_mapping_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            raise FileNotFoundError(f"Q/A mapping file not found: {e}")
    
    def create_incremental_evaluations(self, profiles: List[Dict], qa_mapping: Dict, jd_text: str) -> List[Dict]:
        """Create incremental job fit evaluations for each profile version."""
        evaluations = []
        prior_evaluation = None
        
        for i, profile in enumerate(profiles):
            print(f"Generating job fit evaluation for profile v{i+1}...")
            
            start_time = datetime.now()
            
            # Generate evaluation for this profile version
            evaluation = self.evaluator.generate_job_fit_evaluation(profile, qa_mapping, jd_text, prior_evaluation)
            
            processing_time = (datetime.now() - start_time).total_seconds()
            
            # Create evaluation record
            evaluation_record = copy.deepcopy(self.evaluation_schema)
            evaluation_record['evaluation_version'] = i + 1
            evaluation_record['profile_version'] = profile.get('profile_version', i + 1)
            evaluation_record['summary_text'] = evaluation.get('summary_text', '')
            evaluation_record['reasoning_points'] = evaluation.get('reasoning_points', [])
            evaluation_record['job_fit_assessment'] = evaluation.get('job_fit_assessment', {})
            evaluation_record['timestamp'] = datetime.now().isoformat()
            evaluation_record['llm_metadata']['fallback_mode'] = evaluation.get('fallback_mode', False)
            evaluation_record['llm_metadata']['processing_time'] = processing_time
            
            evaluations.append(evaluation_record)
            prior_evaluation = evaluation_record
        
        return evaluations
    
    def create_final_consolidated_evaluation(self, evaluations: List[Dict], jd_text: str) -> Dict:
        """Create final consolidated evaluation from all incremental evaluations."""
        if not evaluations:
            return {"error": "No evaluations available for consolidation"}
        
        last_evaluation = evaluations[-1]
        final_fit_assessment = last_evaluation.get('job_fit_assessment', {})
        
        # Analyze progression over time
        fit_progression = []
        for eval_record in evaluations:
            fit_status = eval_record.get('job_fit_assessment', {}).get('fit_status', 'weak_fit')
            fit_progression.append({
                'evaluation_version': eval_record.get('evaluation_version', 0),
                'fit_status': fit_status,
                'timestamp': eval_record.get('timestamp', '')
            })
        
        # Determine overall trend
        if len(fit_progression) >= 2:
            early_fit = fit_progression[0]['fit_status']
            final_fit = fit_progression[-1]['fit_status']
            
            fit_trend = "stable"
            if early_fit == "weak_fit" and final_fit in ["partial_fit", "strong_fit"]:
                fit_trend = "improving"
            elif early_fit in ["partial_fit", "strong_fit"] and final_fit == "weak_fit":
                fit_trend = "declining"
        else:
            fit_trend = "insufficient_data"
        
        consolidated = {
            "metadata": {
                "total_evaluations": len(evaluations),
                "processing_timestamp": datetime.now().isoformat(),
                "llm_model": "qwen2.5:3b-instruct",
                "jd_file_provided": bool(jd_text.strip())
            },
            "final_evaluation": {
                "overall_summary": last_evaluation.get('summary_text', ''),
                "final_job_fit_verdict": final_fit_assessment.get('fit_status', 'weak_fit'),
                "strongest_supporting_evidence": final_fit_assessment.get('evidence_answer_ids', []),
                "key_risks_or_gaps": final_fit_assessment.get('missing_or_weak_areas', []),
                "matching_requirements": final_fit_assessment.get('matching_requirements', []),
                "confidence_level": last_evaluation.get('confidence_level', 'low')
            },
            "evaluation_progression": fit_progression,
            "fit_trend_analysis": {
                "trend": fit_trend,
                "early_fit_status": fit_progression[0]['fit_status'] if fit_progression else 'unknown',
                "final_fit_status": fit_progression[-1]['fit_status'] if fit_progression else 'unknown'
            }
        }
        
        return consolidated
    
    def save_evaluations(self, evaluations: List[Dict], output_dir: str, video_name: str) -> List[str]:
        """Save all evaluations and final consolidated evaluation."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        saved_files = []
        
        # Save incremental evaluations
        for evaluation in evaluations:
            version = evaluation['evaluation_version']
            filename = f"{video_name}_evaluation_v{version}.json"
            filepath = output_path / filename
            
            with open(filepath, 'w') as f:
                json.dump(evaluation, f, indent=2)
            
            saved_files.append(str(filepath))
            print(f"✅ Saved evaluation v{version}: {filepath}")
        
        # Save final consolidated evaluation
        consolidated = self.create_final_consolidated_evaluation(evaluations, "")
        consolidated_filename = f"{video_name}_final_job_fit_evaluation.json"
        consolidated_filepath = output_path / consolidated_filename
        
        with open(consolidated_filepath, 'w') as f:
            json.dump(consolidated, f, indent=2)
        
        saved_files.append(str(consolidated_filepath))
        print(f"✅ Saved final consolidated evaluation: {consolidated_filepath}")
        
        return saved_files


def process(profile_dir: str, qa_mapping_path: str, jd_path: str, output_dir: str = "data/final") -> Dict:
    """
    Main processing function for Phase 7.
    Generate incremental LLM-based job fit evaluations and final assessment.
    """
    print("🤖 Phase 7: Incremental LLM-Based Reasoning, Summarization, and Job-Fit Evaluation")
    print(f"📁 Profile directory: {profile_dir}")
    print(f"📁 Q/A mapping: {qa_mapping_path}")
    print(f"📁 Job Description: {jd_path}")
    print(f"📁 Output directory: {output_dir}")
    
    # Validate inputs
    profile_path_obj = Path(profile_dir)
    qa_mapping_path_obj = Path(qa_mapping_path)
    jd_path_obj = Path(jd_path)
    
    if not profile_path_obj.exists():
        raise FileNotFoundError(f"Profile directory not found: {profile_dir}")
    if not qa_mapping_path_obj.exists():
        raise FileNotFoundError(f"Q/A mapping file not found: {qa_mapping_path}")
    if not jd_path_obj.exists():
        raise FileNotFoundError(f"Job description file not found: {jd_path}")
    
    # Extract video name from QA mapping path
    video_name = qa_mapping_path_obj.stem.replace('_qa_mapping', '')
    
    # Initialize evaluator
    evaluator = IncrementalJobFitEvaluator()
    
    # Load job description
    print("📄 Loading job description...")
    jd_text = evaluator.load_jd(jd_path)
    print(f"   Loaded JD ({len(jd_text)} characters)")
    
    # Load profile data
    print("📖 Loading profile versions...")
    profiles = evaluator.load_profiles(profile_dir, video_name)
    print(f"   Loaded {len(profiles)} profile versions")
    
    # Load Q/A mapping
    print("📖 Loading Q/A mapping...")
    qa_mapping = evaluator.load_qa_mapping(qa_mapping_path)
    print(f"   Loaded {len(qa_mapping.get('qa_pairs', []))} Q/A pairs")
    
    if not profiles:
        print("⚠️  No profiles found to process")
        return {
            'video_name': video_name,
            'profiles_processed': 0,
            'evaluations_created': 0,
            'saved_files': [],
            'output_directory': output_dir,
            'llm_available': False,
            'final_fit_status': 'unknown',
            'error': 'No profiles found'
        }
    
    # Generate incremental evaluations
    print("🧠 Generating incremental job fit evaluations...")
    evaluations = evaluator.create_incremental_evaluations(profiles, qa_mapping, jd_text)
    print(f"   Generated {len(evaluations)} evaluation versions")
    
    # Save evaluations
    print("💾 Saving evaluations...")
    saved_files = evaluator.save_evaluations(evaluations, output_dir, video_name)
    
    # Generate statistics
    print(f"\n📊 Job Fit Evaluation Statistics:")
    print(f"   Profile versions processed: {len(profiles)}")
    print(f"   Evaluation versions created: {len(evaluations)}")
    print(f"   Files saved: {len(saved_files)}")
    
    # Check LLM availability
    fallback_used = any(e.get('llm_metadata', {}).get('fallback_mode', False) for e in evaluations)
    if fallback_used:
        print(f"   ⚠️  Used fallback mode (LLM unavailable)")
    else:
        print(f"   ✅ Used LLM-based evaluation")
    
    # Job fit analysis
    if evaluations:
        final_eval = evaluations[-1].get('job_fit_assessment', {})
        fit_status = final_eval.get('fit_status', 'unknown')
        confidence = final_eval.get('confidence_level', 'low')
        
        print(f"\n📋 Final Job Fit Assessment:")
        print(f"   Overall Fit Status: {fit_status}")
        print(f"   Confidence Level: {confidence}")
        print(f"   Matching Requirements: {len(final_eval.get('matching_requirements', []))}")
        print(f"   Areas for Improvement: {len(final_eval.get('missing_or_weak_areas', []))}")
        
        avg_processing_time = sum(e.get('llm_metadata', {}).get('processing_time', 0) for e in evaluations) / len(evaluations)
        print(f"   Average processing time: {avg_processing_time:.2f}s")
    
    return {
        'video_name': video_name,
        'profiles_processed': len(profiles),
        'evaluations_created': len(evaluations),
        'saved_files': saved_files,
        'output_directory': output_dir,
        'llm_available': not fallback_used,
        'final_fit_status': evaluations[-1].get('job_fit_assessment', {}).get('fit_status', 'weak_fit') if evaluations else 'unknown'
    }


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) != 4:
        print("Usage: python process.py <profile_dir> <qa_mapping_path> <jd_path>")
        print("Example: python process.py data/final data/intermediate/phase_04/test_video/test_video_qa_mapping.json test/jd.txt")
        sys.exit(1)
    
    profile_dir = sys.argv[1]
    qa_mapping_path = sys.argv[2]
    jd_path = sys.argv[3]
    
    try:
        result = process(profile_dir, qa_mapping_path, jd_path)
        print("\n🎉 Phase 7 completed successfully!")
        print(f"📁 Created {result['evaluations_created']} evaluation versions")
        print(f"📁 Output directory: {result['output_directory']}")
        print(f"🎯 Final job fit status: {result['final_fit_status']}")
        if result.get('llm_available'):
            print("✅ LLM-based evaluation successful")
        else:
            print("⚠️  Fallback mode used (LLM unavailable)")
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)