import json
import numpy as np
import librosa
from pathlib import Path
import os
from typing import List, Dict, Tuple
import tempfile
import subprocess
import sys


def check_whisper_available():
    """Check if Whisper is available."""
    try:
        import whisper
        return True, whisper
    except ImportError:
        return False, None


def load_faster_whisper():
    """Load faster-whisper if available."""
    try:
        from faster_whisper import WhisperModel
        return True, WhisperModel
    except ImportError:
        return False, None


def extract_audio_segment(full_audio: np.ndarray, sr: int, start_time: float, end_time: float) -> np.ndarray:
    """Extract audio segment from full audio based on timestamps."""
    start_sample = int(start_time * sr)
    end_sample = int(end_time * sr)
    return full_audio[start_sample:end_sample]


def transcribe_segment_whisper(audio_segment: np.ndarray, sr: int, model_size: str = "base") -> Dict:
    """Transcribe audio segment using Whisper."""
    try:
        import whisper
    except ImportError:
        raise ImportError("Whisper not installed. Install with: pip install openai-whisper")
    
    # Load Whisper model
    model = whisper.load_model(model_size)
    
    # Save segment to temporary file
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_file:
        temp_path = temp_file.name
        
        # Save audio segment
        import soundfile as sf
        sf.write(temp_path, audio_segment, sr)
        
        try:
            # Transcribe
            result = model.transcribe(temp_path, word_timestamps=True)
            
            transcript_data = {
                'text': str(result['text']).strip() if isinstance(result['text'], str) else str(result['text']),
                'language': result.get('language', 'en'),
                'words': []
            }
            
            # Extract word-level timestamps if available
            if 'segments' in result and result['segments']:
                for segment in result['segments']:
                    if isinstance(segment, dict) and 'words' in segment and segment['words']:
                        for word in segment['words']:
                            if isinstance(word, dict):
                                transcript_data['words'].append({
                                    'word': word.get('word', ''),
                                    'start': word.get('start', 0.0),
                                    'end': word.get('end', 0.0)
                                })
            
            return transcript_data
            
        finally:
            # Clean up temporary file
            os.unlink(temp_path)


def transcribe_segment_faster_whisper(audio_segment: np.ndarray, sr: int, model_size: str = "base") -> Dict:
    """Transcribe audio segment using faster-whisper."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise ImportError("faster-whisper not installed. Install with: pip install faster-whisper")
    
    # Initialize faster-whisper model
    model = WhisperModel(model_size, compute_type="default")
    
    # Save segment to temporary file
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_file:
        temp_path = temp_file.name
        
        # Save audio segment
        import soundfile as sf
        sf.write(temp_path, audio_segment, sr)
        
        try:
            # Transcribe
            segments, info = model.transcribe(temp_path, word_timestamps=True)
            
            transcript_data = {
                'text': '',
                'language': info.language,
                'words': []
            }
            
            # Collect transcription results
            for segment in segments:
                transcript_data['text'] += segment.text
                
                for word in segment.words:
                    transcript_data['words'].append({
                        'word': word.word,
                        'start': word.start,
                        'end': word.end
                    })
            
            transcript_data['text'] = transcript_data['text'].strip()
            
            return transcript_data
            
        finally:
            # Clean up temporary file
            os.unlink(temp_path)


def transcribe_segment(audio_segment: np.ndarray, sr: int, model_type: str = "whisper", model_size: str = "base") -> Dict:
    """Transcribe audio segment using available Whisper implementation."""
    if model_type == "faster-whisper":
        return transcribe_segment_faster_whisper(audio_segment, sr, model_size)
    else:
        return transcribe_segment_whisper(audio_segment, sr, model_size)


def load_audio(audio_path: str, sr: int = 16000) -> Tuple[np.ndarray, int]:
    """Load audio file and resample if necessary."""
    try:
        audio, loaded_sr = librosa.load(audio_path, sr=sr)
        return audio, int(loaded_sr)
    except Exception as e:
        raise ValueError(f"Failed to load audio file {audio_path}: {e}")


def load_diarization_map(diarization_path: str) -> Dict:
    """Load diarization map from Phase 2 output."""
    with open(diarization_path, 'r') as f:
        return json.load(f)


def process(audio_path: str, diarization_path: str, output_dir: str = "data/intermediate/phase_03",
            model_type: str = "whisper", model_size: str = "base") -> Dict:
    """Main processing function for Phase 3 transcription."""
    # Validate inputs
    audio_path_obj = Path(audio_path)
    diarization_path_obj = Path(diarization_path)
    
    if not audio_path_obj.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")
    
    if not diarization_path_obj.exists():
        raise FileNotFoundError(f"Diarization file not found: {diarization_path}")
    
    # Create output directory
    output_dir_obj = Path(output_dir)
    phase_output_dir = output_dir_obj / audio_path_obj.stem
    phase_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Load audio and diarization
    audio, sr = load_audio(audio_path)
    diarization_map = load_diarization_map(diarization_path)
    
    # Check if soundfile is available for saving audio segments
    try:
        import soundfile
    except ImportError:
        raise ImportError("soundfile not installed. Install with: pip install soundfile")
    
    # Transcribe each segment
    transcript_segments = []
    
    for i, segment in enumerate(diarization_map['segments']):
        print(f"Transcribing segment {i+1}/{len(diarization_map['segments'])}: {segment['speaker']} ({segment['start_time']:.2f}s - {segment['end_time']:.2f}s)")
        
        # Extract audio segment
        audio_segment = extract_audio_segment(audio, sr, segment['start_time'], segment['end_time'])
        
        # Skip very short segments
        if len(audio_segment) < sr * 0.5:  # Less than 0.5 seconds
            print(f"Skipping short segment ({len(audio_segment)/sr:.2f}s)")
            continue
        
        try:
            # Transcribe segment
            transcript = transcribe_segment(audio_segment, sr, model_type, model_size)
            
            # Create transcript segment
            transcript_segment = {
                'speaker': segment['speaker'],
                'start_time': segment['start_time'],
                'end_time': segment['end_time'],
                'duration': segment['duration'],
                'text': transcript['text'],
                'language': transcript['language'],
                'confidence': None,  # Whisper doesn't provide segment-level confidence by default
                'words': transcript['words']
            }
            
            transcript_segments.append(transcript_segment)
            
        except Exception as e:
            print(f"Error transcribing segment {i+1}: {e}")
            # Create empty segment for failed transcriptions
            transcript_segment = {
                'speaker': segment['speaker'],
                'start_time': segment['start_time'],
                'end_time': segment['end_time'],
                'duration': segment['duration'],
                'text': '',
                'language': 'unknown',
                'confidence': None,
                'words': [],
                'error': str(e)
            }
            transcript_segments.append(transcript_segment)
    
    # Create transcript map
    transcript_map = {
        'audio_file': str(audio_path_obj.absolute()),
        'diarization_file': str(diarization_path_obj.absolute()),
        'total_duration': diarization_map['total_duration'],
        'model': {
            'type': model_type,
            'size': model_size
        },
        'segments': transcript_segments,
        'statistics': {
            'total_segments': len(transcript_segments),
            'successful_transcriptions': len([s for s in transcript_segments if s['text'] and not s.get('error')]),
            'failed_transcriptions': len([s for s in transcript_segments if s.get('error')]),
            'speakers': list(set(s['speaker'] for s in transcript_segments)),
            'total_words': sum(len(s['words']) for s in transcript_segments),
            'language_distribution': {}
        }
    }
    
    # Calculate language distribution
    for segment in transcript_segments:
        lang = segment['language']
        if lang not in transcript_map['statistics']['language_distribution']:
            transcript_map['statistics']['language_distribution'][lang] = 0
        transcript_map['statistics']['language_distribution'][lang] += 1
    
    # Save transcript map
    transcript_path = phase_output_dir / f"{audio_path_obj.stem}_transcript.json"
    with open(transcript_path, 'w') as f:
        json.dump(transcript_map, f, indent=2)
    
    return {
        'transcript_path': str(transcript_path),
        'transcript_map': transcript_map
    }


def get_speaker_transcripts(transcript_map: Dict) -> Dict[str, List[Dict]]:
    """Get transcripts grouped by speaker."""
    speaker_transcripts = {}
    
    for segment in transcript_map['segments']:
        speaker = segment['speaker']
        if speaker not in speaker_transcripts:
            speaker_transcripts[speaker] = []
        
        speaker_transcripts[speaker].append({
            'text': segment['text'],
            'start_time': segment['start_time'],
            'end_time': segment['end_time'],
            'duration': segment['duration']
        })
    
    return speaker_transcripts


def export_plain_text(transcript_map: Dict, output_path: str):
    """Export transcript as plain text format."""
    with open(output_path, 'w') as f:
        for segment in transcript_map['segments']:
            f.write(f"[{segment['speaker']}] ({segment['start_time']:.2f}s - {segment['end_time']:.2f}s)\n")
            f.write(f"{segment['text']}\n\n")


def export_srt(transcript_map: Dict, output_path: str):
    """Export transcript as SRT subtitle format."""
    with open(output_path, 'w') as f:
        for i, segment in enumerate(transcript_map['segments']):
            start_time = format_srt_time(segment['start_time'])
            end_time = format_srt_time(segment['end_time'])
            
            f.write(f"{i + 1}\n")
            f.write(f"{start_time} --> {end_time}\n")
            f.write(f"[{segment['speaker']}] {segment['text']}\n\n")


def format_srt_time(seconds: float) -> str:
    """Format seconds as SRT timestamp (HH:MM:SS,mmm)."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    milliseconds = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{milliseconds:03d}"