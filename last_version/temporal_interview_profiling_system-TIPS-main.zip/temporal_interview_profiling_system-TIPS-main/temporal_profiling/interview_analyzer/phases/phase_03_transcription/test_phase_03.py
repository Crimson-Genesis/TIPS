import os
import json
import tempfile
import shutil
from pathlib import Path
import numpy as np

from process import load_audio, extract_audio_segment, get_speaker_transcripts


def test_load_audio():
    """Test audio loading function."""
    # Test with simple validation
    try:
        # This will fail but we can test the function structure
        load_audio("nonexistent.wav", 16000)
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "Failed to load audio file" in str(e)


def test_extract_audio_segment():
    """Test audio segment extraction."""
    # Create test audio (10 seconds at 16kHz)
    full_audio = np.random.randn(160000)
    sr = 16000
    
    # Extract segment from 2s to 4s
    segment = extract_audio_segment(full_audio, sr, 2.0, 4.0)
    
    expected_length = 2 * sr  # 2 seconds
    assert len(segment) == expected_length
    
    # Test boundaries
    segment_start = extract_audio_segment(full_audio, sr, 0.0, 1.0)
    assert len(segment_start) == 1 * sr


def test_get_speaker_transcripts():
    """Test speaker transcript grouping."""
    transcript_map = {
        'segments': [
            {
                'speaker': 'SPEAKER_0',
                'text': 'Hello',
                'start_time': 0.0,
                'end_time': 1.0,
                'duration': 1.0
            },
            {
                'speaker': 'SPEAKER_1',
                'text': 'Hi there',
                'start_time': 2.0,
                'end_time': 3.0,
                'duration': 1.0
            },
            {
                'speaker': 'SPEAKER_0',
                'text': 'How are you?',
                'start_time': 4.0,
                'end_time': 5.0,
                'duration': 1.0
            }
        ]
    }
    
    speaker_transcripts = get_speaker_transcripts(transcript_map)
    
    assert 'SPEAKER_0' in speaker_transcripts
    assert 'SPEAKER_1' in speaker_transcripts
    assert len(speaker_transcripts['SPEAKER_0']) == 2
    assert len(speaker_transcripts['SPEAKER_1']) == 1
    
    assert speaker_transcripts['SPEAKER_0'][0]['text'] == 'Hello'
    assert speaker_transcripts['SPEAKER_1'][0]['text'] == 'Hi there'
    assert speaker_transcripts['SPEAKER_0'][1]['text'] == 'How are you?'


def test_process_file_not_found():
    """Test process with non-existent files."""
    try:
        from process import process
        process("nonexistent_audio.wav", "nonexistent_diarization.json")
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError:
        pass


def test_file_structure_validation():
    """Test that the process can validate file structure."""
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create test files
        audio_path = os.path.join(temp_dir, "test_audio.wav")
        diarization_path = os.path.join(temp_dir, "test_diarization.json")
        
        # Create dummy audio file
        with open(audio_path, 'w') as f:
            f.write("dummy audio")
        
        # Create test diarization data
        diarization_data = {
            'total_duration': 10.0,
            'segments': [
                {
                    'speaker': 'SPEAKER_0',
                    'start_time': 0.0,
                    'end_time': 2.0,
                    'duration': 2.0
                },
                {
                    'speaker': 'SPEAKER_1',
                    'start_time': 3.0,
                    'end_time': 5.0,
                    'duration': 2.0
                }
            ]
        }
        
        with open(diarization_path, 'w') as f:
            json.dump(diarization_data, f)
        
        # Test file validation (will fail later in process but validates structure)
        from process import process
        
        try:
            # This will fail at the Whisper/soundfile stage but validates file structure
            process(audio_path, diarization_path, output_dir=temp_dir + "/output")
        except ImportError as e:
            # Expected - dependencies not available in test environment
            assert "whisper" in str(e).lower() or "soundfile" in str(e).lower()
        except Exception as e:
            # Other exceptions might occur but file structure should be valid
            pass


if __name__ == "__main__":
    test_load_audio()
    test_extract_audio_segment()
    test_get_speaker_transcripts()
    test_process_file_not_found()
    test_file_structure_validation()
    print("All Phase 3 tests passed!")