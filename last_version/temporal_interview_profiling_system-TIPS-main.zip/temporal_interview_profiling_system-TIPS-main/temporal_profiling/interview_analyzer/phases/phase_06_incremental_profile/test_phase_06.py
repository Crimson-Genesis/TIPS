#!/usr/bin/env python3

import sys
import os
import json
from pathlib import Path

# Add Phase 6 to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'phases', 'phase_06_incremental_profile'))

def create_test_features():
    """Create test feature data."""
    return {
        "metadata": {
            "phase": 5,
            "description": "Deterministic Feature Extraction (Post Speaker Correction)",
            "processing_timestamp": "2026-02-02T05:30:22.340832",
            "total_answers_processed": 3,
            "valid_answers": 2,
            "empty_answers": 1
        },
        "global_statistics": {
            "average_speech_rate": 3.4,
            "average_filler_word_ratio": 0.125,
            "average_complexity_score": 7.571428571428571,
            "average_pause_duration_before_answer": 4.0
        },
        "feature_definitions": {
            "word_count": "Total number of words in answer",
            "speaking_duration": "Duration of answer in seconds",
            "speech_rate": "Words spoken per second",
            "filler_word_count": "Count of filler words (um, uh, like, etc.)",
            "filler_word_ratio": "Ratio of filler words to total words",
            "lexical_diversity": "Unique words divided by total words",
            "complexity_score": "Combined measure of word complexity and variety",
            "pause_duration_before_answer": "Silence duration before answer starts"
        },
        "answers": [
            {
                "answer_id": "q_1",
                "question_id": "q_1",
                "answer_start_time": 10.0,
                "answer_end_time": 15.0,
                "word_count": 14,
                "speaking_duration": 5.0,
                "speech_rate": 2.8,
                "filler_word_count": 0,
                "filler_word_ratio": 0.0,
                "lexical_diversity": 1.0,
                "pause_duration_before_answer": 4.0,
                "complexity_score": 8.392857142857142
            },
            {
                "answer_id": "q_2",
                "question_id": "q_2",
                "answer_start_time": 25.0,
                "answer_end_time": 26.0,
                "word_count": 4,
                "speaking_duration": 1.0,
                "speech_rate": 4.0,
                "filler_word_count": 1,
                "filler_word_ratio": 0.25,
                "lexical_diversity": 1.0,
                "pause_duration_before_answer": 4.0,
                "complexity_score": 6.75
            },
            {
                "answer_id": "q_3",
                "question_id": "q_3",
                "answer_start_time": 0,
                "answer_end_time": 0,
                "word_count": 0,
                "speaking_duration": 0,
                "speech_rate": 0.0,
                "filler_word_count": 0,
                "filler_word_ratio": 0.0,
                "lexical_diversity": 0.0,
                "pause_duration_before_answer": 0.0,
                "complexity_score": 0.0
            }
        ]
    }

def create_test_qa_mapping():
    """Create test Q/A mapping data."""
    return {
        "metadata": {
            "phase": 4,
            "description": "Question-Answer Mapping",
            "mapping_method": "deterministic",
            "total_qa_pairs": 3
        },
        "qa_pairs": [
            {
                "question_id": "q_1",
                "question_text": "Can you tell me about your experience with system design?",
                "question_start_time": 5.0,
                "answer_text": "I have worked on several large-scale systems including distributed databases and microservices architectures.",
                "answer_start_time": 10.0,
                "answer_end_time": 15.0,
                "linked_segment_ids": ["seg_0", "seg_1"]
            },
            {
                "question_id": "q_2", 
                "question_text": "What about React?",
                "question_start_time": 20.0,
                "answer_text": "I know React well.",
                "answer_start_time": 25.0,
                "answer_end_time": 26.0,
                "linked_segment_ids": ["seg_2", "seg_3"]
            },
            {
                "question_id": "q_3",
                "question_text": "How do you handle scalability?",
                "question_start_time": 30.0,
                "answer_text": "",
                "answer_start_time": 0,
                "answer_end_time": 0,
                "linked_segment_ids": ["seg_4"]
            }
        ]
    }

def test_incremental_profile_construction():
    """Test incremental profile construction."""
    from process import IncrementalProfileBuilder
    
    print("🧪 Phase 6 Test: Incremental Profile Construction")
    
    # Create test data
    features_data = create_test_features()
    qa_mapping_data = create_test_qa_mapping()
    
    # Create temporary test files
    test_dir = Path("data/final/test")
    test_dir.mkdir(parents=True, exist_ok=True)
    
    features_file = test_dir / "test_features.json"
    qa_file = test_dir / "test_qa_mapping.json"
    
    with open(features_file, 'w') as f:
        json.dump(features_data, f, indent=2)
    
    with open(qa_file, 'w') as f:
        json.dump(qa_mapping_data, f, indent=2)
    
    print(f"📁 Created test files: {features_file}, {qa_file}")
    
    try:
        # Initialize builder
        builder = IncrementalProfileBuilder()
        
        # Load and merge data
        features, qa_mapping = builder.load_inputs(str(features_file), str(qa_file))
        merged_records = builder.merge_qa_with_features(qa_mapping, features)
        
        print(f"   Merged {len(merged_records)} records")
        
        # Create incremental profiles
        profiles = builder.create_incremental_profiles(merged_records)
        
        if len(profiles) != 3:
            print(f"❌ Expected 3 profiles, got {len(profiles)}")
            return False
        
        # Test profile v1 (only q_1)
        profile_v1 = profiles[0]
        if (profile_v1['profile_version'] != 1 or
            len(profile_v1['processed_question_ids']) != 1 or
            profile_v1['processed_question_ids'] != ['q_1']):
            print(f"❌ Profile v1 incorrect: {profile_v1}")
            return False
        
        # Test profile v2 (q_1 + q_2)
        profile_v2 = profiles[1]
        if (profile_v2['profile_version'] != 2 or
            len(profile_v2['processed_question_ids']) != 2 or
            set(profile_v2['processed_question_ids']) != {'q_1', 'q_2'}):
            print(f"❌ Profile v2 incorrect: {profile_v2}")
            return False
        
        # Test profile v3 (q_1 + q_2 + q_3)
        profile_v3 = profiles[2]
        if (profile_v3['profile_version'] != 3 or
            len(profile_v3['processed_question_ids']) != 3 or
            set(profile_v3['processed_question_ids']) != {'q_1', 'q_2', 'q_3'}):
            print(f"❌ Profile v3 incorrect: {profile_v3}")
            return False
        
        # Test aggregated metrics
        v3_metrics = profile_v3['aggregated_metrics']
        if (v3_metrics['total_questions_processed'] != 3 or
            v3_metrics['total_valid_answers'] != 2 or
            v3_metrics['total_empty_answers'] != 1 or
            v3_metrics['cumulative_word_count'] != 18):  # 14 + 4 + 0
            print(f"❌ Profile v3 metrics incorrect: {v3_metrics}")
            return False
        
        print("✅ Test PASSED: Incremental profile construction")
        return True
        
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_profile_continuity():
    """Test that Profile_v(n+1) contains Profile_v(n)."""
    from process import IncrementalProfileBuilder
    
    print("🧪 Phase 6 Test: Profile Continuity")
    
    # Create test data with 2 answers
    features_data = {
        "answers": [
            {
                "answer_id": "q_1",
                "question_id": "q_1",
                "word_count": 10,
                "speaking_duration": 2.0,
                "speech_rate": 5.0,
                "filler_word_count": 0,
                "filler_word_ratio": 0.0,
                "lexical_diversity": 1.0,
                "pause_duration_before_answer": 1.0,
                "complexity_score": 7.0
            },
            {
                "answer_id": "q_2",
                "question_id": "q_2",
                "word_count": 5,
                "speaking_duration": 1.0,
                "speech_rate": 5.0,
                "filler_word_count": 1,
                "filler_word_ratio": 0.2,
                "lexical_diversity": 1.0,
                "pause_duration_before_answer": 2.0,
                "complexity_score": 6.0
            }
        ]
    }
    
    qa_mapping_data = {
        "qa_pairs": [
            {
                "question_id": "q_1",
                "question_text": "First question?",
                "answer_text": "First answer",
                "answer_start_time": 10.0,
                "answer_end_time": 12.0,
                "linked_segment_ids": ["seg_1"]
            },
            {
                "question_id": "q_2",
                "question_text": "Second question?",
                "answer_text": "Second answer",
                "answer_start_time": 20.0,
                "answer_end_time": 21.0,
                "linked_segment_ids": ["seg_2"]
            }
        ]
    }
    
    try:
        builder = IncrementalProfileBuilder()
        merged_records = builder.merge_qa_with_features(qa_mapping_data, features_data)
        profiles = builder.create_incremental_profiles(merged_records)
        
        if len(profiles) != 2:
            print(f"❌ Expected 2 profiles, got {len(profiles)}")
            return False
        
        profile_v1 = profiles[0]
        profile_v2 = profiles[1]
        
        # Check that v2 contains all records from v1
        v1_ids = set(r['question_id'] for r in profile_v1['per_answer_records'])
        v2_ids = set(r['question_id'] for r in profile_v2['per_answer_records'])
        
        if not v1_ids.issubset(v2_ids):
            print(f"❌ Profile v2 doesn't contain all v1 records: {v1_ids} vs {v2_ids}")
            return False
        
        # Check that v2 has additional record
        if len(profile_v2['per_answer_records']) != len(profile_v1['per_answer_records']) + 1:
            print(f"❌ Profile v2 should have one more record than v1")
            return False
        
        # Check deterministic ordering
        if profile_v2['processed_question_ids'] != ['q_1', 'q_2']:
            print(f"❌ Incorrect question ordering: {profile_v2['processed_question_ids']}")
            return False
        
        print("✅ Test PASSED: Profile continuity")
        return True
        
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_missing_feature_handling():
    """Test handling of missing feature vectors."""
    from process import IncrementalProfileBuilder
    
    print("🧪 Phase 6 Test: Missing Feature Vector Handling")
    
    # Create test data where one answer is missing features
    features_data = {
        "answers": [
            {
                "answer_id": "q_1",
                "question_id": "q_1",
                "word_count": 10,
                "speaking_duration": 2.0,
                "speech_rate": 5.0,
                "filler_word_count": 0,
                "filler_word_ratio": 0.0,
                "lexical_diversity": 1.0,
                "pause_duration_before_answer": 1.0,
                "complexity_score": 7.0
            }
            # Note: q_2 missing from features
        ]
    }
    
    qa_mapping_data = {
        "qa_pairs": [
            {
                "question_id": "q_1",
                "question_text": "First question?",
                "answer_text": "First answer",
                "answer_start_time": 10.0,
                "answer_end_time": 12.0,
                "linked_segment_ids": ["seg_1"]
            },
            {
                "question_id": "q_2",
                "question_text": "Second question?",
                "answer_text": "Second answer",
                "answer_start_time": 20.0,
                "answer_end_time": 21.0,
                "linked_segment_ids": ["seg_2"]
            }
        ]
    }
    
    try:
        builder = IncrementalProfileBuilder()
        merged_records = builder.merge_qa_with_features(qa_mapping_data, features_data)
        
        # Should only have 1 record (q_2 should be skipped)
        if len(merged_records) != 1:
            print(f"❌ Expected 1 merged record, got {len(merged_records)}")
            return False
        
        if merged_records[0]['question_id'] != 'q_1':
            print(f"❌ Expected q_1 record, got {merged_records[0]['question_id']}")
            return False
        
        print("✅ Test PASSED: Missing feature vector handling")
        return True
        
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def test_deterministic_ordering():
    """Test deterministic ordering of records."""
    from process import IncrementalProfileBuilder
    
    print("🧪 Phase 6 Test: Deterministic Ordering")
    
    # Create test data with 3 answers in random order
    features_data = {
        "answers": [
            {
                "answer_id": "q_3",
                "question_id": "q_3",
                "word_count": 3,
                "speaking_duration": 1.0,
                "speech_rate": 3.0,
                "filler_word_count": 0,
                "filler_word_ratio": 0.0,
                "lexical_diversity": 1.0,
                "pause_duration_before_answer": 1.0,
                "complexity_score": 7.0
            },
            {
                "answer_id": "q_1",
                "question_id": "q_1",
                "word_count": 5,
                "speaking_duration": 1.0,
                "speech_rate": 5.0,
                "filler_word_count": 0,
                "filler_word_ratio": 0.0,
                "lexical_diversity": 1.0,
                "pause_duration_before_answer": 2.0,
                "complexity_score": 6.0
            },
            {
                "answer_id": "q_2",
                "question_id": "q_2",
                "word_count": 8,
                "speaking_duration": 2.0,
                "speech_rate": 4.0,
                "filler_word_count": 1,
                "filler_word_ratio": 0.125,
                "lexical_diversity": 1.0,
                "pause_duration_before_answer": 1.5,
                "complexity_score": 8.0
            }
        ]
    }
    
    qa_mapping_data = {
        "qa_pairs": [
            {
                "question_id": "q_1",
                "question_text": "First question?",
                "answer_text": "First answer",
                "answer_start_time": 5.0,
                "answer_end_time": 6.0,
                "linked_segment_ids": ["seg_1"]
            },
            {
                "question_id": "q_2",
                "question_text": "Second question?",
                "answer_text": "Second answer",
                "answer_start_time": 15.0,
                "answer_end_time": 17.0,
                "linked_segment_ids": ["seg_2"]
            },
            {
                "question_id": "q_3",
                "question_text": "Third question?",
                "answer_text": "Third answer",
                "answer_start_time": 25.0,
                "answer_end_time": 26.0,
                "linked_segment_ids": ["seg_3"]
            }
        ]
    }
    
    try:
        builder = IncrementalProfileBuilder()
        merged_records = builder.merge_qa_with_features(qa_mapping_data, features_data)
        profiles = builder.create_incremental_profiles(merged_records)
        
        # Should maintain Q/A mapping order: q_1, q_2, q_3
        expected_order = ['q_1', 'q_2', 'q_3']
        
        for i, profile in enumerate(profiles):
            expected_ids = expected_order[:i+1]
            actual_ids = profile['processed_question_ids']
            
            if actual_ids != expected_ids:
                print(f"❌ Profile v{i+1} wrong order: expected {expected_ids}, got {actual_ids}")
                return False
        
        print("✅ Test PASSED: Deterministic ordering")
        return True
        
    except Exception as e:
        print(f"❌ Test FAILED: {e}")
        return False

def main():
    """Run all Phase 6 tests."""
    print("🧪 Phase 6 Incremental Profile Construction Test Suite")
    print("=" * 60)
    
    # Create test directory
    test_dir = Path("data/final/test")
    test_dir.mkdir(parents=True, exist_ok=True)
    
    # Run tests
    tests = [
        ("Incremental Profile Construction", test_incremental_profile_construction),
        ("Profile Continuity", test_profile_continuity),
        ("Missing Feature Handling", test_missing_feature_handling),
        ("Deterministic Ordering", test_deterministic_ordering)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n🧪 Running: {test_name}")
        result = test_func()
        results.append((test_name, result))
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 Test Summary:")
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {test_name}: {status}")
        if result:
            passed += 1
    
    print(f"\n🎯 Tests passed: {passed}/{len(tests)}")
    
    if passed == len(tests):
        print("🎉 All tests passed!")
        return True
    else:
        print("❌ Some tests failed!")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)