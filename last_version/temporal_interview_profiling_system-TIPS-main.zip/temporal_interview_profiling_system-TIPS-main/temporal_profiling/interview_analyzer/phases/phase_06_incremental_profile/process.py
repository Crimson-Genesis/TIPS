import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import copy


class IncrementalProfileBuilder:
    """Build incremental candidate profiles from feature vectors and Q/A metadata."""
    
    def __init__(self):
        self.profile_schema = {
            "profile_version": 0,
            "processed_question_ids": [],
            "aggregated_metrics": {
                "total_questions_processed": 0,
                "total_valid_answers": 0,
                "total_empty_answers": 0,
                "cumulative_word_count": 0,
                "cumulative_speaking_duration": 0.0,
                "average_speech_rate": 0.0,
                "cumulative_filler_word_count": 0,
                "average_filler_ratio": 0.0,
                "average_complexity_score": 0.0,
                "average_pause_duration": 0.0
            },
            "per_answer_records": [],
            "timestamps": {
                "created_at": None,
                "last_updated": None
            }
        }
    
    def load_inputs(self, features_path: str, qa_mapping_path: str) -> Tuple[Dict, Dict]:
        """Load Phase 5 features and Phase 4 Q/A mapping."""
        try:
            with open(features_path, 'r') as f:
                features_data = json.load(f)
            
            with open(qa_mapping_path, 'r') as f:
                qa_mapping_data = json.load(f)
            
            return features_data, qa_mapping_data
            
        except FileNotFoundError as e:
            raise FileNotFoundError(f"Input file not found: {e}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in input file: {e}")
    
    def merge_qa_with_features(self, qa_mapping: Dict, features: Dict) -> List[Dict]:
        """Merge Q/A metadata with feature vectors."""
        qa_pairs = qa_mapping.get('qa_pairs', [])
        answers = features.get('answers', [])
        
        # Create lookup dictionary for features by answer_id
        feature_lookup = {answer.get('answer_id'): answer for answer in answers}
        
        merged_records = []
        for qa_pair in qa_pairs:
            question_id = qa_pair.get('question_id', '')
            feature_data = feature_lookup.get(question_id, {})
            
            if not feature_data:
                print(f"⚠️  Missing feature vector for question {question_id}, skipping")
                continue
            
            merged_record = {
                'question_id': question_id,
                'question_text': qa_pair.get('question_text', ''),
                'question_start_time': qa_pair.get('question_start_time', 0),
                'answer_text': qa_pair.get('answer_text', ''),
                'answer_start_time': qa_pair.get('answer_start_time', 0),
                'answer_end_time': qa_pair.get('answer_end_time', 0),
                'linked_segment_ids': qa_pair.get('linked_segment_ids', []),
                'features': {
                    'word_count': feature_data.get('word_count', 0),
                    'speaking_duration': feature_data.get('speaking_duration', 0.0),
                    'speech_rate': feature_data.get('speech_rate', 0.0),
                    'filler_word_count': feature_data.get('filler_word_count', 0),
                    'filler_word_ratio': feature_data.get('filler_word_ratio', 0.0),
                    'lexical_diversity': feature_data.get('lexical_diversity', 0.0),
                    'complexity_score': feature_data.get('complexity_score', 0.0),
                    'pause_duration_before_answer': feature_data.get('pause_duration_before_answer', 0.0)
                }
            }
            merged_records.append(merged_record)
        
        return merged_records
    
    def compute_aggregated_metrics(self, records: List[Dict]) -> Dict:
        """Compute aggregated metrics from processed records."""
        if not records:
            return copy.deepcopy(self.profile_schema['aggregated_metrics'])
        
        total_questions = len(records)
        valid_answers = [r for r in records if r['features']['word_count'] > 0]
        empty_answers = total_questions - len(valid_answers)
        
        if valid_answers:
            cumulative_word_count = sum(r['features']['word_count'] for r in valid_answers)
            cumulative_speaking_duration = sum(r['features']['speaking_duration'] for r in valid_answers)
            cumulative_filler_count = sum(r['features']['filler_word_count'] for r in valid_answers)
            cumulative_pause_duration = sum(r['features']['pause_duration_before_answer'] for r in valid_answers)
            
            avg_speech_rate = cumulative_word_count / cumulative_speaking_duration if cumulative_speaking_duration > 0 else 0.0
            avg_filler_ratio = cumulative_filler_count / cumulative_word_count if cumulative_word_count > 0 else 0.0
            avg_complexity = sum(r['features']['complexity_score'] for r in valid_answers) / len(valid_answers)
            avg_pause_duration = cumulative_pause_duration / total_questions
        else:
            cumulative_word_count = 0
            cumulative_speaking_duration = 0.0
            cumulative_filler_count = 0
            avg_speech_rate = 0.0
            avg_filler_ratio = 0.0
            avg_complexity = 0.0
            avg_pause_duration = 0.0
        
        return {
            "total_questions_processed": total_questions,
            "total_valid_answers": len(valid_answers),
            "total_empty_answers": empty_answers,
            "cumulative_word_count": cumulative_word_count,
            "cumulative_speaking_duration": cumulative_speaking_duration,
            "average_speech_rate": avg_speech_rate,
            "cumulative_filler_word_count": cumulative_filler_count,
            "average_filler_ratio": avg_filler_ratio,
            "average_complexity_score": avg_complexity,
            "average_pause_duration": avg_pause_duration
        }
    
    def create_incremental_profiles(self, records: List[Dict]) -> List[Dict]:
        """Create incremental profiles - one for each processed answer."""
        if not records:
            return []
        
        profiles = []
        cumulative_records = []
        
        for i, record in enumerate(records):
            cumulative_records.append(record)
            
            # Compute metrics for all answers processed so far
            aggregated_metrics = self.compute_aggregated_metrics(cumulative_records)
            
            # Create profile version i+1
            profile = copy.deepcopy(self.profile_schema)
            profile['profile_version'] = i + 1
            profile['processed_question_ids'] = [r['question_id'] for r in cumulative_records]
            profile['aggregated_metrics'] = aggregated_metrics
            profile['per_answer_records'] = copy.deepcopy(cumulative_records)
            profile['timestamps']['created_at'] = datetime.now().isoformat()
            profile['timestamps']['last_updated'] = datetime.now().isoformat()
            
            profiles.append(profile)
        
        return profiles
    
    def save_profiles(self, profiles: List[Dict], output_dir: str, video_name: str):
        """Save all profile versions to separate files."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        saved_files = []
        for profile in profiles:
            version = profile['profile_version']
            filename = f"{video_name}_profile_v{version}.json"
            filepath = output_path / filename
            
            with open(filepath, 'w') as f:
                json.dump(profile, f, indent=2)
            
            saved_files.append(str(filepath))
            print(f"✅ Saved profile v{version}: {filepath}")
        
        return saved_files


def process(features_path: str, qa_mapping_path: str, output_dir: str = "data/final") -> Dict:
    """
    Main processing function for Phase 6.
    Build incremental candidate profiles from features and Q/A metadata.
    """
    print("🔧 Phase 6: Incremental Candidate Profile Construction")
    print(f"📁 Features input: {features_path}")
    print(f"📁 Q/A mapping input: {qa_mapping_path}")
    print(f"📁 Output directory: {output_dir}")
    
    # Validate inputs
    features_path_obj = Path(features_path)
    qa_mapping_path_obj = Path(qa_mapping_path)
    
    if not features_path_obj.exists():
        raise FileNotFoundError(f"Features file not found: {features_path}")
    if not qa_mapping_path_obj.exists():
        raise FileNotFoundError(f"Q/A mapping file not found: {qa_mapping_path}")
    
    # Extract video name from path
    video_name = features_path_obj.stem.replace('_features', '')
    
    # Initialize profile builder
    builder = IncrementalProfileBuilder()
    
    # Load input data
    print("📖 Loading input data...")
    features_data, qa_mapping_data = builder.load_inputs(features_path, qa_mapping_path)
    print(f"   Loaded {len(features_data.get('answers', []))} feature vectors")
    print(f"   Loaded {len(qa_mapping_data.get('qa_pairs', []))} Q/A pairs")
    
    # Merge Q/A metadata with features
    print("🔗 Merging Q/A metadata with feature vectors...")
    merged_records = builder.merge_qa_with_features(qa_mapping_data, features_data)
    print(f"   Merged {len(merged_records)} records")
    
    # Create incremental profiles
    print("📈 Building incremental profiles...")
    profiles = builder.create_incremental_profiles(merged_records)
    print(f"   Created {len(profiles)} profile versions")
    
    # Save profiles
    print("💾 Saving profile versions...")
    saved_files = builder.save_profiles(profiles, output_dir, video_name)
    
    # Generate summary
    print(f"\n📊 Profile Construction Summary:")
    print(f"   Total profile versions: {len(profiles)}")
    print(f"   Input records processed: {len(merged_records)}")
    print(f"   Profiles saved to: {output_dir}")
    
    if profiles:
        final_profile = profiles[-1]
        metrics = final_profile['aggregated_metrics']
        print(f"\n📋 Final Profile (v{final_profile['profile_version']}) Metrics:")
        print(f"   Total questions: {metrics['total_questions_processed']}")
        print(f"   Valid answers: {metrics['total_valid_answers']}")
        print(f"   Empty answers: {metrics['total_empty_answers']}")
        print(f"   Total words spoken: {metrics['cumulative_word_count']}")
        print(f"   Total speaking time: {metrics['cumulative_speaking_duration']:.1f}s")
        print(f"   Average speech rate: {metrics['average_speech_rate']:.2f} words/sec")
        print(f"   Average filler ratio: {metrics['average_filler_ratio']:.3f}")
        print(f"   Average complexity: {metrics['average_complexity_score']:.2f}")
        print(f"   Average pause duration: {metrics['average_pause_duration']:.2f}s")
    
    return {
        'video_name': video_name,
        'profiles_created': len(profiles),
        'records_processed': len(merged_records),
        'saved_files': saved_files,
        'final_profile': profiles[-1] if profiles else None,
        'output_directory': output_dir
    }


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) != 3:
        print("Usage: python process.py <features_path> <qa_mapping_path>")
        print("Example: python process.py data/intermediate/phase_05/test_video/test_video_features.json data/intermediate/phase_04/test_video/test_video_qa_mapping.json")
        sys.exit(1)
    
    features_path = sys.argv[1]
    qa_mapping_path = sys.argv[2]
    
    try:
        result = process(features_path, qa_mapping_path)
        print("\n🎉 Phase 6 completed successfully!")
        print(f"📁 Created {result['profiles_created']} profile versions")
        print(f"📁 Output directory: {result['output_directory']}")
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)