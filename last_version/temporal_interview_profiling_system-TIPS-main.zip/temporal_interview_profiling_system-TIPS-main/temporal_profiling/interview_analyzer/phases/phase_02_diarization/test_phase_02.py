import os
import json
import tempfile
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock
import numpy as np

from process import load_audio, detect_voice_activity, smooth_voice_activity, simple_speaker_diarization, process, get_speaker_mapping


def test_load_audio():
    """Test audio loading function."""
    # Test with mock
    with patch('librosa.load') as mock_load:
        mock_load.return_value = (np.array([0.1, 0.2, 0.3]), 16000)
        
        audio, sr = load_audio("test.wav", 16000)
        
        assert len(audio) == 3
        assert sr == 16000
        mock_load.assert_called_once_with("test.wav", sr=16000)


def test_detect_voice_activity():
    """Test voice activity detection."""
    # Create test audio with clear energy differences
    audio = np.array([0.01, 0.02, 0.01, 0.5, 0.6, 0.4, 0.01, 0.02, 0.01])
    
    voice_frames, energy = detect_voice_activity(audio, sr=16000, frame_length=3, hop_length=1, energy_threshold=0.1)
    
    assert len(voice_frames) > 0
    assert len(energy) > 0
    assert voice_frames.dtype == bool
    assert energy.dtype in [float, np.float64, np.float32]


def test_smooth_voice_activity():
    """Test smoothing of voice activity."""
    # Create test voice frames with longer sequences
    voice_frames = np.array([False, False, True, True, True, True, True, False, False, True, True, True, True, False, False])
    
    segments = smooth_voice_activity(voice_frames, min_silence_duration=0.2, min_speech_duration=0.1, sr=16000, hop_length=512)
    
    assert isinstance(segments, list)
    # Check that segments are tuples with (start_time, end_time)
    for segment in segments:
        assert len(segment) == 2
        assert segment[0] < segment[1]


def test_simple_speaker_diarization():
    """Test speaker diarization."""
    # Create test speech segments
    speech_segments = [(0.0, 2.0), (3.0, 5.0), (6.0, 8.0)]
    
    # Create test audio
    audio = np.random.randn(160000)  # 10 seconds at 16kHz
    
    segments = simple_speaker_diarization(audio, 16000, speech_segments)
    
    assert isinstance(segments, list)
    assert len(segments) >= 1
    
    # Check segment structure
    for segment in segments:
        assert 'speaker' in segment
        assert 'start_time' in segment
        assert 'end_time' in segment
        assert 'duration' in segment
        assert 'energy' in segment
        assert 'zcr' in segment
        assert segment['speaker'] in ['SPEAKER_0', 'SPEAKER_1']
        assert segment['start_time'] < segment['end_time']


def test_process_file_not_found():
    """Test process with non-existent file."""
    try:
        process("nonexistent_audio.wav")
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError:
        pass


def test_process_success():
    """Test successful processing."""
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create test audio file path (mock)
        audio_path = os.path.join(temp_dir, "test_audio.wav")
        # Create dummy file to pass existence check
        with open(audio_path, 'w') as f:
            f.write("dummy")
        
        with patch('process.load_audio') as mock_load, \
             patch('process.detect_voice_activity') as mock_vad, \
             patch('process.smooth_voice_activity') as mock_smooth, \
             patch('process.simple_speaker_diarization') as mock_diarize:
            
            # Setup mocks
            mock_load.return_value = (np.random.randn(160000), 16000)
            mock_vad.return_value = (np.array([True, False, True]), np.array([0.1, 0.05, 0.2]))
            mock_smooth.return_value = [(0.0, 2.0), (3.0, 5.0)]
            mock_diarize.return_value = [
                {
                    'speaker': 'SPEAKER_0',
                    'start_time': 0.0,
                    'end_time': 2.0,
                    'duration': 2.0,
                    'energy': 0.1,
                    'zcr': 0.05
                },
                {
                    'speaker': 'SPEAKER_1',
                    'start_time': 3.0,
                    'end_time': 5.0,
                    'duration': 2.0,
                    'energy': 0.15,
                    'zcr': 0.08
                }
            ]
            
            result = process(audio_path, output_dir=temp_dir + "/output")
            
            assert 'diarization_path' in result
            assert 'diarization_map' in result
            
            # Check diarization map structure
            diarization_map = result['diarization_map']
            assert 'audio_file' in diarization_map
            assert 'total_duration' in diarization_map
            assert 'parameters' in diarization_map
            assert 'segments' in diarization_map
            assert 'statistics' in diarization_map
            
            # Check statistics
            stats = diarization_map['statistics']
            assert 'total_segments' in stats
            assert 'speakers' in stats
            assert 'speaker_durations' in stats


def test_get_speaker_mapping():
    """Test speaker mapping to roles."""
    diarization_map = {
        'statistics': {
            'speaker_durations': {
                'SPEAKER_0': 120.5,
                'SPEAKER_1': 85.3
            }
        }
    }
    
    mapping = get_speaker_mapping(diarization_map)
    
    assert 'interviewer' in mapping
    assert 'candidate' in mapping
    assert mapping['candidate'] == 'SPEAKER_0'  # Speaker with longer duration
    assert mapping['interviewer'] == 'SPEAKER_1'


def test_process_creates_directory_structure():
    """Test that process creates correct directory structure."""
    with tempfile.TemporaryDirectory() as temp_dir:
        audio_path = os.path.join(temp_dir, "test_audio.wav")
        # Create dummy file to pass existence check
        with open(audio_path, 'w') as f:
            f.write("dummy")
        
        with patch('process.load_audio') as mock_load, \
             patch('process.detect_voice_activity') as mock_vad, \
             patch('process.smooth_voice_activity') as mock_smooth, \
             patch('process.simple_speaker_diarization') as mock_diarize:
            
            mock_load.return_value = (np.random.randn(160000), 16000)
            mock_vad.return_value = (np.array([True, False]), np.array([0.1, 0.05]))
            mock_smooth.return_value = [(0.0, 2.0)]
            mock_diarize.return_value = [{
                'speaker': 'SPEAKER_0',
                'start_time': 0.0,
                'end_time': 2.0,
                'duration': 2.0,
                'energy': 0.1,
                'zcr': 0.05
            }]
            
            process(audio_path, output_dir=temp_dir + "/output")
            
            expected_dir = Path(temp_dir + "/output/test_audio")
            assert expected_dir.exists()
            
            expected_file = expected_dir / "test_audio_diarization.json"
            assert expected_file.exists()


if __name__ == "__main__":
    test_load_audio()
    test_detect_voice_activity()
    test_smooth_voice_activity()
    test_simple_speaker_diarization()
    test_process_file_not_found()
    test_process_success()
    test_get_speaker_mapping()
    test_process_creates_directory_structure()
    print("All Phase 2 tests passed!")