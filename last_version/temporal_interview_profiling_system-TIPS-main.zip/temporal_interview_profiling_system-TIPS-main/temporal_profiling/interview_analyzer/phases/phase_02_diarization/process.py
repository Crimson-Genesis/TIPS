import json
import numpy as np
import librosa
from pathlib import Path
import os
from typing import List, Dict, Tuple


def load_audio(audio_path: str, sr: int = 16000) -> Tuple[np.ndarray, int]:
    """Load audio file and resample if necessary."""
    try:
        audio, loaded_sr = librosa.load(audio_path, sr=sr)
        return audio, int(loaded_sr)
    except Exception as e:
        raise ValueError(f"Failed to load audio file {audio_path}: {e}")


def detect_voice_activity(audio: np.ndarray, sr: int, 
                          frame_length: int = 1024, 
                          hop_length: int = 512,
                          energy_threshold: float = 0.01) -> Tuple[np.ndarray, np.ndarray]:
    """Detect voice activity using energy-based approach."""
    # Calculate short-time energy
    energy = librosa.feature.rms(
        y=audio, 
        frame_length=frame_length, 
        hop_length=hop_length
    )[0]
    
    # Ensure energy is numpy array
    energy = np.array(energy)
    
    # Normalize energy
    if energy.max() > 0:
        energy = energy / energy.max()
    
    # Voice activity detection
    voice_frames = np.array(energy > energy_threshold)
    
    return voice_frames, energy


def smooth_voice_activity(voice_frames: np.ndarray, 
                         min_silence_duration: float = 0.3,
                         min_speech_duration: float = 0.5,
                         sr: int = 16000,
                         hop_length: int = 512) -> List[Tuple[float, float]]:
    """Smooth voice activity by removing very short segments."""
    frame_duration = hop_length / sr
    
    # Convert frames to time
    frame_times = np.arange(len(voice_frames)) * frame_duration
    
    # Find speech segments
    speech_segments = []
    in_speech = False
    start_time = 0
    
    for i, is_speech in enumerate(voice_frames):
        time = frame_times[i]
        
        if is_speech and not in_speech:
            # Start of speech segment
            in_speech = True
            start_time = time
        elif not is_speech and in_speech:
            # End of speech segment
            in_speech = False
            duration = time - start_time
            if duration >= min_speech_duration:
                speech_segments.append((start_time, time))
    
    # Handle case where audio ends with speech
    if in_speech:
        duration = frame_times[-1] - start_time
        if duration >= min_speech_duration:
            speech_segments.append((start_time, frame_times[-1]))
    
    # Merge segments separated by short silence
    merged_segments = []
    if speech_segments:
        current_start, current_end = speech_segments[0]
        
        for start, end in speech_segments[1:]:
            if start - current_end <= min_silence_duration:
                # Merge with current segment
                current_end = end
            else:
                merged_segments.append((current_start, current_end))
                current_start, current_end = start, end
        
        merged_segments.append((current_start, current_end))
    
    return merged_segments


def simple_speaker_diarization(audio: np.ndarray, sr: int, 
                             speech_segments: List[Tuple[float, float]],
                             speaker_switch_threshold: float = 10.0) -> List[Dict]:
    """Simple speaker diarization based on energy patterns and turn-taking."""
    segments = []
    
    for i, (start_time, end_time) in enumerate(speech_segments):
        # Extract segment audio
        start_sample = int(start_time * sr)
        end_sample = int(end_time * sr)
        segment_audio = audio[start_sample:end_sample]
        
        # Calculate segment features
        energy = np.mean(segment_audio ** 2)
        zcr = np.mean(librosa.feature.zero_crossing_rate(segment_audio)[0])
        
        # Simple speaker labeling: alternate between SPEAKER_0 and SPEAKER_1
        # This is a heuristic - in practice, more sophisticated methods are used
        speaker = f"SPEAKER_{i % 2}"
        
        # Adjust speaker based on energy patterns (interviewer vs candidate)
        if i > 0:
            prev_segment = segments[-1]
            # If energy is much higher, might be candidate speaking
            if energy > prev_segment.get('energy', 0) * speaker_switch_threshold:
                # Switch speaker pattern
                speaker = "SPEAKER_0" if prev_segment['speaker'] == "SPEAKER_1" else "SPEAKER_1"
        
        segments.append({
            'speaker': speaker,
            'start_time': round(start_time, 2),
            'end_time': round(end_time, 2),
            'duration': round(end_time - start_time, 2),
            'energy': float(energy),
            'zcr': float(zcr)
        })
    
    # Post-process: merge consecutive segments from same speaker
    merged_segments = []
    if segments:
        current_segment = segments[0].copy()
        
        for segment in segments[1:]:
            if segment['speaker'] == current_segment['speaker']:
                # Merge segments
                current_segment['end_time'] = segment['end_time']
                current_segment['duration'] = round(
                    current_segment['end_time'] - current_segment['start_time'], 2
                )
                current_segment['energy'] = max(
                    current_segment.get('energy', 0), segment.get('energy', 0)
                )
            else:
                merged_segments.append(current_segment)
                current_segment = segment.copy()
        
        merged_segments.append(current_segment)
    
    return merged_segments


def process(audio_path: str, output_dir: str = "data/intermediate/phase_02",
            sr: int = 16000, energy_threshold: float = 0.01,
            min_silence_duration: float = 0.3,
            min_speech_duration: float = 0.5) -> Dict:
    """Main processing function for Phase 2 diarization."""
    audio_path_obj = Path(audio_path)
    
    if not audio_path_obj.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")
    
    # Create output directory
    output_dir_obj = Path(output_dir)
    phase_output_dir = output_dir_obj / audio_path_obj.stem
    phase_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Load audio
    audio, loaded_sr = load_audio(audio_path, sr)
    
    # Voice activity detection
    voice_frames, energy = detect_voice_activity(audio, sr, energy_threshold=energy_threshold)
    
    # Extract speech segments
    speech_segments = smooth_voice_activity(
        voice_frames, min_silence_duration, min_speech_duration, sr
    )
    
    # Speaker diarization
    diarization_segments = simple_speaker_diarization(audio, sr, speech_segments)
    
    # Create diarization map
    diarization_map = {
        'audio_file': str(audio_path_obj.absolute()),
        'total_duration': round(len(audio) / sr, 2),
        'parameters': {
            'sample_rate': sr,
            'energy_threshold': energy_threshold,
            'min_silence_duration': min_silence_duration,
            'min_speech_duration': min_speech_duration
        },
        'segments': diarization_segments,
        'statistics': {
            'total_segments': len(diarization_segments),
            'speakers': list(set(seg['speaker'] for seg in diarization_segments)),
            'speaker_durations': {}
        }
    }
    
    # Calculate speaker statistics
    for seg in diarization_segments:
        speaker = seg['speaker']
        if speaker not in diarization_map['statistics']['speaker_durations']:
            diarization_map['statistics']['speaker_durations'][speaker] = 0
        diarization_map['statistics']['speaker_durations'][speaker] += seg['duration']
    
    # Save diarization map
    diarization_path = phase_output_dir / f"{audio_path_obj.stem}_diarization.json"
    with open(diarization_path, 'w') as f:
        json.dump(diarization_map, f, indent=2)
    
    return {
        'diarization_path': str(diarization_path),
        'diarization_map': diarization_map
    }


def get_speaker_mapping(diarization_map: Dict) -> Dict[str, str]:
    """Get suggested mapping of speakers to roles (interviewer/candidate)."""
    speaker_durations = diarization_map['statistics']['speaker_durations']
    
    # Assume speaker with longer total duration is candidate
    candidate_speaker = max(speaker_durations.keys(), key=lambda k: speaker_durations[k])
    interviewer_speaker = [k for k in speaker_durations.keys() if k != candidate_speaker][0]
    
    return {
        'interviewer': interviewer_speaker,
        'candidate': candidate_speaker
    }