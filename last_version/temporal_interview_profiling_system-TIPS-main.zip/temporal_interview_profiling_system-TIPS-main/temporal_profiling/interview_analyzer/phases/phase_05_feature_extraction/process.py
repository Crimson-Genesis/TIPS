import json
import re
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from collections import Counter
from datetime import datetime


class FeatureExtractor:
    """Deterministic feature extraction from corrected Q/A pairs."""
    
    # Common filler words in English
    FILLER_WORDS = {
        'um', 'uh', 'er', 'ah', 'like', 'you know', 'I mean', 'well', 'so', 
        'basically', 'actually', 'kind of', 'sort of', 'right', 'okay'
    }
    
    def __init__(self):
        # Initialize minimal dependencies
        self.punctuation_pattern = re.compile(r'[^\w\s]')
        self.word_pattern = re.compile(r'\b\w+\b')
    
    def extract_features_from_answer(self, answer_data: Dict, answer_text: str) -> Dict:
        """
        Extract deterministic features from a candidate answer.
        
        Args:
            answer_data: Answer data from Q/A mapping
            answer_text: Cleaned answer text
            
        Returns:
            Dictionary with extracted features
        """
        features = {
            'answer_id': answer_data.get('answer_id', ''),
            'question_id': answer_data.get('question_id', ''),
            'answer_start_time': answer_data.get('answer_start_time', 0),
            'answer_end_time': answer_data.get('answer_end_time', 0),
            'word_count': 0,
            'speaking_duration': 0,
            'speech_rate': 0.0,
            'filler_word_count': 0,
            'filler_word_ratio': 0.0,
            'lexical_diversity': 0.0,
            'pause_duration_before_answer': 0.0,
            'complexity_score': 0.0
        }
        
        # Calculate basic temporal features
        if features['answer_end_time'] > features['answer_start_time']:
            features['speaking_duration'] = features['answer_end_time'] - features['answer_start_time']
        
        # Text preprocessing
        if not answer_text or answer_text.strip() == "":
            return features  # Empty answer case
        
        # Word-level features
        words = self.word_pattern.findall(answer_text.lower())
        features['word_count'] = len(words)
        
        # Speech rate (words per second)
        if features['speaking_duration'] > 0:
            features['speech_rate'] = features['word_count'] / features['speaking_duration']
        
        # Filler word analysis
        filler_count = 0
        for word in words:
            if word in self.FILLER_WORDS:
                filler_count += 1
        
        features['filler_word_count'] = filler_count
        if features['word_count'] > 0:
            features['filler_word_ratio'] = filler_count / features['word_count']
        
        # Lexical diversity (unique words / total words)
        unique_words = len(set(words))
        if features['word_count'] > 0:
            features['lexical_diversity'] = unique_words / features['word_count']
        
        # Complexity score (based on average word length and variety)
        if features['word_count'] > 0:
            avg_word_length = sum(len(word) for word in words) / features['word_count']
            features['complexity_score'] = (avg_word_length + features['lexical_diversity'] * 10) / 2
        
        return features
    
    def extract_silence_features(self, segments: List[Dict], answer_start: float) -> float:
        """
        Calculate pause duration before answer using surrounding segments.
        """
        if not segments or answer_start <= 0:
            return 0.0
        
        # Find the segment immediately before answer start
        pause_duration = 0.0
        min_gap = float('inf')
        
        for segment in segments:
            if segment.get('end_time', 0) < answer_start:
                gap = answer_start - segment.get('end_time', 0)
                if gap > 0 and gap < min_gap:
                    min_gap = gap
        
        if min_gap != float('inf'):
            pause_duration = min_gap
        
        return pause_duration
    
    def load_phase4_outputs(self, qa_mapping_path: str, corrected_transcript_path: str) -> Tuple[Dict, List[Dict]]:
        """Load Phase 4 outputs."""
        try:
            with open(qa_mapping_path, 'r') as f:
                qa_mapping = json.load(f)
            
            with open(corrected_transcript_path, 'r') as f:
                corrected_transcript = json.load(f)
            
            return qa_mapping, corrected_transcript.get('segments', [])
            
        except FileNotFoundError as e:
            raise FileNotFoundError(f"Phase 4 output not found: {e}")
    
    def extract_features_for_all_answers(self, qa_mapping: Dict, segments: List[Dict]) -> List[Dict]:
        """Extract features for all answers in Q/A mapping."""
        qa_pairs = qa_mapping.get('qa_pairs', [])
        answer_features = []
        
        for qa_pair in qa_pairs:
            answer_text = qa_pair.get('answer_text', '').strip()
            
            # Calculate pause before answer
            answer_start = qa_pair.get('answer_start_time', 0)
            pause_duration = self.extract_silence_features(segments, answer_start)
            
            # Extract features from answer
            answer_data = {
                'answer_id': qa_pair.get('question_id', ''),
                'question_id': qa_pair.get('question_id', ''),
                'answer_start_time': answer_start,
                'answer_end_time': qa_pair.get('answer_end_time', 0)
            }
            
            features = self.extract_features_from_answer(answer_data, answer_text)
            features['pause_duration_before_answer'] = pause_duration
            
            answer_features.append(features)
        
        return answer_features


def process(qa_mapping_path: str, corrected_transcript_path: str, output_dir: str = "data/intermediate/phase_05") -> Dict:
    """
    Main processing function for Phase 5.
    Extract deterministic features from corrected Q/A pairs.
    """
    print("🔧 Phase 5: Deterministic Feature Extraction (Post Speaker Correction)")
    print(f"📁 Q/A Mapping: {qa_mapping_path}")
    print(f"📁 Corrected Transcript: {corrected_transcript_path}")
    print(f"📁 Output: {output_dir}")
    
    # Validate inputs
    qa_path_obj = Path(qa_mapping_path)
    transcript_path_obj = Path(corrected_transcript_path)
    
    if not qa_path_obj.exists():
        raise FileNotFoundError(f"Q/A mapping file not found: {qa_mapping_path}")
    if not transcript_path_obj.exists():
        raise FileNotFoundError(f"Corrected transcript file not found: {corrected_transcript_path}")
    
    # Create output directory
    output_dir_obj = Path(output_dir)
    phase_output_dir = output_dir_obj / qa_path_obj.stem.replace('_qa_mapping', '')
    phase_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Initialize feature extractor
    extractor = FeatureExtractor()
    
    # Load Phase 4 outputs
    print("📖 Loading Phase 4 outputs...")
    qa_mapping, segments = extractor.load_phase4_outputs(qa_mapping_path, corrected_transcript_path)
    
    total_qa_pairs = len(qa_mapping.get('qa_pairs', []))
    print(f"   Loaded {total_qa_pairs} Q/A pairs")
    print(f"   Loaded {len(segments)} transcript segments")
    
    # Extract features for all answers
    print("🔍 Extracting deterministic features...")
    answer_features = extractor.extract_features_for_all_answers(qa_mapping, segments)
    print(f"   Extracted features for {len(answer_features)} answers")
    
    # Calculate global statistics
    valid_answers = [f for f in answer_features if f['word_count'] > 0]
    
    if valid_answers:
        avg_speech_rate = np.mean([f['speech_rate'] for f in valid_answers])
        avg_filler_ratio = np.mean([f['filler_word_ratio'] for f in valid_answers])
        avg_complexity = np.mean([f['complexity_score'] for f in valid_answers])
        avg_pause = np.mean([f['pause_duration_before_answer'] for f in valid_answers])
    else:
        avg_speech_rate = avg_filler_ratio = avg_complexity = avg_pause = 0.0
    
    # Create output data structure
    output_data = {
        'metadata': {
            'phase': 5,
            'description': 'Deterministic Feature Extraction (Post Speaker Correction)',
            'processing_timestamp': datetime.now().isoformat(),
            'total_answers_processed': len(answer_features),
            'valid_answers': len(valid_answers),
            'empty_answers': len(answer_features) - len(valid_answers),
            'input_qa_mapping_path': qa_mapping_path,
            'input_corrected_transcript_path': corrected_transcript_path
        },
        'global_statistics': {
            'average_speech_rate': float(avg_speech_rate),
            'average_filler_word_ratio': float(avg_filler_ratio),
            'average_complexity_score': float(avg_complexity),
            'average_pause_duration_before_answer': float(avg_pause)
        },
        'feature_definitions': {
            'word_count': 'Total number of words in answer',
            'speaking_duration': 'Duration of answer in seconds',
            'speech_rate': 'Words spoken per second',
            'filler_word_count': 'Count of filler words (um, uh, like, etc.)',
            'filler_word_ratio': 'Ratio of filler words to total words',
            'lexical_diversity': 'Unique words divided by total words',
            'complexity_score': 'Combined measure of word complexity and variety',
            'pause_duration_before_answer': 'Silence duration before answer starts'
        },
        'answers': answer_features
    }
    
    # Save features output
    features_path = phase_output_dir / f"{qa_path_obj.stem.replace('_qa_mapping', '')}_features.json"
    
    with open(features_path, 'w') as f:
        json.dump(output_data, f, indent=2)
    
    print(f"✅ Features saved: {features_path}")
    
    # Generate statistics
    stats = {
        'total_answers': len(answer_features),
        'valid_answers': len(valid_answers),
        'empty_answers': len(answer_features) - len(valid_answers),
        'avg_word_count': np.mean([f['word_count'] for f in valid_answers]) if valid_answers else 0,
        'avg_speaking_duration': np.mean([f['speaking_duration'] for f in valid_answers]) if valid_answers else 0,
        'avg_speech_rate': float(avg_speech_rate),
        'avg_filler_ratio': float(avg_filler_ratio),
        'avg_complexity': float(avg_complexity),
        'avg_pause_before': float(avg_pause),
        'min_word_count': min([f['word_count'] for f in valid_answers]) if valid_answers else 0,
        'max_word_count': max([f['word_count'] for f in valid_answers]) if valid_answers else 0
    }
    
    print(f"\n📊 Feature Extraction Statistics:")
    print(f"   Total answers processed: {stats['total_answers']}")
    print(f"   Valid answers: {stats['valid_answers']}")
    print(f"   Empty answers: {stats['empty_answers']}")
    print(f"   Average word count: {stats['avg_word_count']:.1f}")
    print(f"   Average speaking duration: {stats['avg_speaking_duration']:.1f}s")
    print(f"   Average speech rate: {stats['avg_speech_rate']:.2f} words/sec")
    print(f"   Average filler ratio: {stats['avg_filler_ratio']:.3f}")
    print(f"   Average complexity: {stats['avg_complexity']:.2f}")
    print(f"   Average pause before answer: {stats['avg_pause_before']:.2f}s")
    print(f"   Word count range: {stats['min_word_count']} - {stats['max_word_count']}")
    
    return {
        'features_path': str(features_path),
        'output_data': output_data,
        'statistics': stats
    }


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) != 3:
        print("Usage: python process.py <qa_mapping_path> <corrected_transcript_path>")
        print("Example: python process.py data/intermediate/phase_04/test_video/test_video_qa_mapping.json data/intermediate/phase_04/test_video/test_video_corrected.json")
        sys.exit(1)
    
    qa_mapping_path = sys.argv[1]
    corrected_transcript_path = sys.argv[2]
    
    try:
        result = process(qa_mapping_path, corrected_transcript_path)
        print("\n🎉 Phase 5 completed successfully!")
        print(f"📁 Features saved to: {result['features_path']}")
        print(f"📊 Processed {result['statistics']['total_answers']} answers")
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)