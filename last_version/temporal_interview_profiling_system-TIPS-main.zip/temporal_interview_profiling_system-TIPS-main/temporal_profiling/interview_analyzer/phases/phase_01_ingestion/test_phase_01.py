import os
import json
import tempfile
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock

from process import extract_audio, extract_metadata, process


def test_extract_audio_creates_output_directory():
    with tempfile.TemporaryDirectory() as temp_dir:
        video_path = "test_video.mp4"
        output_dir = Path(temp_dir) / "output"
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock()
            
            result = extract_audio(video_path, str(output_dir))
            
            assert output_dir.exists()
            assert "test_video.wav" in result


def test_extract_audio_ffmpeg_command():
    with tempfile.TemporaryDirectory() as temp_dir:
        video_path = "test_video.mp4"
        output_dir = temp_dir
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock()
            
            extract_audio(video_path, output_dir)
            
            mock_run.assert_called_once()
            args = mock_run.call_args[0][0]
            assert args[0] == "ffmpeg"
            assert "-i" in args
            assert video_path in args
            assert "-vn" in args
            assert "-acodec" in args


def test_extract_metadata_ffprobe_command():
    video_path = "test_video.mp4"
    
    mock_metadata = {
        "streams": [
            {
                "codec_type": "video",
                "codec_name": "h264",
                "width": 1920,
                "height": 1080,
                "r_frame_rate": "30/1"
            },
            {
                "codec_type": "audio",
                "codec_name": "aac",
                "sample_rate": "48000",
                "channels": 2
            }
        ],
        "format": {
            "duration": "120.5",
            "size": "1048576",
            "bit_rate": "65536"
        }
    }
    
    with patch('subprocess.run') as mock_run:
        mock_run.return_value = MagicMock()
        mock_run.return_value.stdout = json.dumps(mock_metadata)
        mock_run.return_value.returncode = 0
        
        result = extract_metadata(video_path)
        
        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert args[0] == "ffprobe"
        assert "-print_format" in args
        assert "json" in args


def test_extract_metadata_parsing():
    video_path = "test_video.mp4"
    
    mock_metadata = {
        "streams": [
            {
                "codec_type": "video",
                "codec_name": "h264",
                "width": 1920,
                "height": 1080,
                "r_frame_rate": "30/1"
            },
            {
                "codec_type": "audio",
                "codec_name": "aac",
                "sample_rate": "48000",
                "channels": 2
            }
        ],
        "format": {
            "duration": "120.5",
            "size": "1048576",
            "bit_rate": "65536"
        }
    }
    
    with patch('subprocess.run') as mock_run:
        mock_run.return_value = MagicMock()
        mock_run.return_value.stdout = json.dumps(mock_metadata)
        mock_run.return_value.returncode = 0
        
        result = extract_metadata(video_path)
        
        assert result["video"]["codec"] == "h264"
        assert result["video"]["width"] == 1920
        assert result["video"]["height"] == 1080
        assert result["video"]["fps"] == 30
        assert result["audio"]["codec"] == "aac"
        assert result["audio"]["sample_rate"] == "48000"
        assert result["audio"]["channels"] == 2
        assert result["duration"] == 120.5
        assert result["size"] == 1048576
        assert result["bit_rate"] == 65536


def test_process_file_not_found():
    try:
        process("nonexistent_video.mp4")
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError:
        pass


def test_process_success():
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create test video file
        test_video = Path(temp_dir) / "test_video.mp4"
        test_video.touch()
        
        with patch('interview_analyzer.phases.phase_01_ingestion.process.extract_audio') as mock_audio, \
             patch('interview_analyzer.phases.phase_01_ingestion.process.extract_metadata') as mock_metadata:
            
            mock_audio.return_value = "test_video.wav"
            mock_metadata.return_value = {"duration": 120.5, "size": 1000}
            
            result = process(str(test_video), temp_dir + "/output")
            
            assert "audio_path" in result
            assert "metadata_path" in result
            assert "metadata" in result
            mock_audio.assert_called_once()
            mock_metadata.assert_called_once()


def test_process_creates_directory_structure():
    with tempfile.TemporaryDirectory() as temp_dir:
        test_video = Path(temp_dir) / "test_video.mp4"
        test_video.touch()
        
        with patch('interview_analyzer.phases.phase_01_ingestion.process.extract_audio') as mock_audio, \
             patch('interview_analyzer.phases.phase_01_ingestion.process.extract_metadata') as mock_metadata:
            
            mock_audio.return_value = "test_video.wav"
            mock_metadata.return_value = {"duration": 120.5}
            
            process(str(test_video), temp_dir + "/output")
            
            expected_dir = Path(temp_dir + "/output/test_video")
            assert expected_dir.exists()


if __name__ == "__main__":
    test_extract_audio_creates_output_directory()
    test_extract_audio_ffmpeg_command()
    test_extract_metadata_ffprobe_command()
    test_extract_metadata_parsing()
    test_process_file_not_found()
    test_process_success()
    test_process_creates_directory_structure()
    print("All tests passed!")