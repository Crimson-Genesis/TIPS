import json
import os
import subprocess
from pathlib import Path


def extract_audio(video_path: str, output_dir: str) -> str:
    """Extract audio from video file using ffmpeg."""
    video_path_obj = Path(video_path)
    output_dir_obj = Path(output_dir)
    output_dir_obj.mkdir(parents=True, exist_ok=True)
    
    output_audio_path = output_dir_obj / f"{video_path_obj.stem}.wav"
    
    cmd = [
        "ffmpeg",
        "-i", str(video_path),
        "-vn",  # no video
        "-acodec", "pcm_s16le",  # WAV codec
        "-ar", "16000",  # sample rate 16kHz
        "-ac", "1",  # mono
        "-y",  # overwrite output
        str(output_audio_path)
    ]
    
    subprocess.run(cmd, check=True, capture_output=True)
    return str(output_audio_path)


def extract_metadata(video_path: str) -> dict:
    """Extract metadata from video file using ffprobe."""
    cmd = [
        "ffprobe",
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        video_path
    ]
    
    result = subprocess.run(cmd, check=True, capture_output=True, text=True)
    metadata = json.loads(result.stdout)
    
    # Extract relevant fields
    video_streams = [s for s in metadata["streams"] if s["codec_type"] == "video"]
    audio_streams = [s for s in metadata["streams"] if s["codec_type"] == "audio"]
    
    extracted_metadata = {
        "file_path": str(Path(video_path).absolute()),
        "duration": float(metadata["format"]["duration"]),
        "size": int(metadata["format"]["size"]),
        "bit_rate": int(metadata["format"]["bit_rate"]),
        "video": {
            "codec": video_streams[0]["codec_name"] if video_streams else None,
            "width": video_streams[0].get("width") if video_streams else None,
            "height": video_streams[0].get("height") if video_streams else None,
            "fps": eval(video_streams[0].get("r_frame_rate", "0/1")) if video_streams else None
        },
        "audio": {
            "codec": audio_streams[0]["codec_name"] if audio_streams else None,
            "sample_rate": audio_streams[0].get("sample_rate") if audio_streams else None,
            "channels": audio_streams[0].get("channels") if audio_streams else None
        }
    }
    
    return extracted_metadata


def process(video_path: str, output_dir: str = "data/intermediate/phase_01") -> dict:
    """Main processing function for Phase 1."""
    video_path_obj = Path(video_path)
    
    if not video_path_obj.exists():
        raise FileNotFoundError(f"Video file not found: {video_path}")
    
    # Create output directory
    output_dir_obj = Path(output_dir)
    phase_output_dir = output_dir_obj / video_path_obj.stem
    phase_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Extract audio
    audio_path = extract_audio(video_path, str(phase_output_dir))
    
    # Extract metadata
    metadata = extract_metadata(video_path)
    
    # Save metadata to JSON
    metadata_path = phase_output_dir / f"{video_path_obj.stem}_metadata.json"
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f, indent=2)
    
    return {
        "audio_path": audio_path,
        "metadata_path": str(metadata_path),
        "metadata": metadata
    }