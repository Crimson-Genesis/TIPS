import json
import requests
import re
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import sys


class OllamaClient:
    """Local Ollama client for qwen2.5:3b-instruct."""
    
    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url
        self.model = "qwen2.5:3b-instruct"
        self.fallback_mode = False
    
    def is_available(self) -> bool:
        """Check if Ollama is running and model is available."""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get("models", [])
                return any(model.get("name", "").startswith("qwen2.5:3b") for model in models)
        except Exception:
            pass
        return False
    
    def correct_speaker_and_classify(self, segments: List[Dict]) -> List[Dict]:
        """
        Use LLM to correct speaker attribution and classify segment intent.
        Processes in small windows for the small model.
        """
        if not self.is_available():
            self.fallback_mode = True
            return self._fallback_correction(segments)
        
        corrected_segments = []
        
        # Process in smaller windows for faster processing
        window_size = 2  # Reduced from 3 for speed
        overlap = 0  # Reduced overlap for speed
        
        total_windows = (len(segments) + window_size - 1) // window_size
        processed = 0
        
        for i in range(0, len(segments), window_size):
            window_end = min(i + window_size, len(segments))
            window = segments[i:window_end]
            
            if not window:
                continue
                
            processed += 1
            print(f"Processing window {processed}/{total_windows} (segments {i+1}-{window_end})...", flush=True)
            
            prompt = self._create_correction_prompt(window)
            
            try:
                response = self._call_ollama(prompt)
                corrected_window = self._parse_llm_response(response, window)
                corrected_segments.extend(corrected_window)
            except Exception as e:
                print(f"LLM correction failed for window {processed}: {e}")
                # Fall back to original segments with low confidence
                for seg in window:
                    corrected_segments.append({
                        'segment_id': seg.get('segment_id', ''),
                        'text': seg.get('text', ''),
                        'start_time': seg.get('start_time', 0),
                        'end_time': seg.get('end_time', 0),
                        'original_speaker_label': seg.get('speaker', ''),
                        'corrected_speaker_label': seg.get('speaker', ''),
                        'segment_type': 'other',
                        'confidence': 'low'
                    })
        
        return corrected_segments
    
    def _fallback_correction(self, segments: List[Dict]) -> List[Dict]:
        """Fallback method when LLM is not available."""
        print("⚠️  Using fallback correction (LLM unavailable)")
        
        corrected_segments = []
        
        for i, seg in enumerate(segments):
            text = seg.get('text', '').lower()
            original_speaker = seg.get('speaker', '')
            
            # Simple rule-based speaker correction
            corrected_speaker = original_speaker
            if 'question' in text or any(q in text for q in ['what', 'how', 'why', 'can you', 'could you', 'would you', 'tell me', 'describe']):
                # Likely interviewer
                if original_speaker == 'SPEAKER_1':
                    corrected_speaker = 'interviewer'
                else:
                    corrected_speaker = 'interviewer'
            elif any(ans in text for ans in ['i think', 'i believe', 'i have', 'my experience', 'we implemented']):
                # Likely candidate
                corrected_speaker = 'candidate'
            
            # Simple classification
            segment_type = 'other'
            if '?' in text or any(q in text for q in ['what', 'how', 'why', 'can you', 'could you', 'would you', 'tell me']):
                segment_type = 'question'
            elif len(text.split()) > 3 and any(ans in text for ans in ['i think', 'i have', 'we used', 'my experience']):
                segment_type = 'answer'
            
            corrected_segment = {
                'segment_id': seg.get('segment_id', f"seg_{i}"),
                'text': seg.get('text', ''),
                'start_time': seg.get('start_time', 0),
                'end_time': seg.get('end_time', 0),
                'original_speaker_label': original_speaker,
                'corrected_speaker_label': corrected_speaker,
                'segment_type': segment_type,
                'confidence': 'low' if self.fallback_mode else 'medium'
            }
            corrected_segments.append(corrected_segment)
        
        return corrected_segments
    
    def _create_correction_prompt(self, segments: List[Dict]) -> str:
        """Create structured prompt for speaker correction and classification."""
        
        segments_text = ""
        for i, seg in enumerate(segments):
            speaker = seg.get('speaker', f'SPEAKER_{i}')
            text = seg.get('text', '')
            # Truncate very long text to keep prompt small
            if len(text) > 150:
                text = text[:147] + "..."
            segments_text += f"{i+1}. Speaker: {speaker}\nText: {text}\n\n"
        
        prompt = f"""You are analyzing an interview transcript. Your task is to correct speaker labels and classify segment types.

INTERVIEWER DEFINITION:
- Asks questions
- Gives prompts and instructions  
- Speaks in shorter, directive statements
- Uses question words: what, how, why, can you, could you, etc.

CANDIDATE DEFINITION:
- Answers questions
- Explains concepts
- Provides technical details
- Speaks in longer, explanatory statements

SEGMENT CLASSIFICATION:
- question: Segment contains a question or prompt
- answer: Segment contains an answer or explanation
- other: Neither question nor answer (greetings, acknowledgments, transitions)

TRANSCRIPT:
{segments_text}

TASK: Correct speaker labels and classify segments.

INTERVIEWER: Asks questions, uses "what/how/why/can you"
CANDIDATE: Answers questions, explains concepts

OUTPUT ONLY JSON:
[
  {{"segment_id": "id", "corrected_speaker_label": "interviewer|candidate", "segment_type": "question|answer|other", "confidence": "high|medium|low"}}
]"""

        return prompt
    
    def _call_ollama(self, prompt: str) -> str:
        """Make API call to Ollama."""
        response = requests.post(
            f"{self.base_url}/api/generate",
            json={
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.1,  # Low temperature for consistent output
                    "num_predict": 200,   # Smaller response length for faster processing
                    "num_ctx": 1024,      # Smaller context window
                    "top_k": 10,          # Limit token choices
                    "repeat_penalty": 1.1   # Reduce repetition
                }
            },
            timeout=60
        )
        response.raise_for_status()
        return response.json().get("response", "")
    
    def _parse_llm_response(self, response: str, original_segments: List[Dict]) -> List[Dict]:
        """Parse LLM JSON response and combine with original segment data."""
        try:
            # Extract JSON from response (in case of extra text)
            json_match = re.search(r'\[.*?\]', response, re.DOTALL)
            if not json_match:
                raise ValueError("No JSON array found in response")
            
            corrections = json.loads(json_match.group())
            
            if len(corrections) != len(original_segments):
                raise ValueError(f"Expected {len(original_segments)} corrections, got {len(corrections)}")
            
            corrected_segments = []
            for i, (correction, original) in enumerate(zip(corrections, original_segments)):
                corrected_segment = {
                    'segment_id': original.get('segment_id', f"seg_{i}"),
                    'text': original.get('text', ''),
                    'start_time': original.get('start_time', 0),
                    'end_time': original.get('end_time', 0),
                    'original_speaker_label': original.get('speaker', ''),
                    'corrected_speaker_label': correction.get('corrected_speaker_label', original.get('speaker', '')),
                    'segment_type': correction.get('segment_type', 'other'),
                    'confidence': correction.get('confidence', 'low')
                }
                corrected_segments.append(corrected_segment)
            
            return corrected_segments
            
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in LLM response: {e}")
        except Exception as e:
            raise ValueError(f"Failed to parse LLM response: {e}")


def load_transcript(transcript_path: str) -> Dict:
    """Load transcript from Phase 3 output."""
    with open(transcript_path, 'r') as f:
        return json.load(f)


def deterministic_qa_mapping(corrected_segments: List[Dict]) -> List[Dict]:
    """
    Create deterministic question-answer mapping without LLM.
    Follows strict chronological rules.
    """
    qa_pairs = []
    
    # Find all question segments
    questions = []
    for i, segment in enumerate(corrected_segments):
        if (segment.get('corrected_speaker_label') == 'interviewer' and 
            segment.get('segment_type') == 'question'):
            questions.append((i, segment))
    
    # Map each question to following answers
    for q_idx, (segment_idx, question) in enumerate(questions):
        # Find answer segments after this question
        answer_segments = []
        next_segment_idx = segment_idx + 1
        
        while (next_segment_idx < len(corrected_segments) and
               len(answer_segments) < 5):  # Limit answer length
            next_seg = corrected_segments[next_segment_idx]
            
            if (next_seg.get('corrected_speaker_label') == 'candidate' and
                next_seg.get('segment_type') in ['answer', 'other']):
                # Include 'other' segments as part of answer if from candidate
                answer_segments.append(next_seg)
            elif (next_seg.get('corrected_speaker_label') == 'interviewer' and
                  next_seg.get('segment_type') == 'question'):
                # New question starts, stop this answer
                break
            else:
                # Non-relevant segment, stop
                break
            
            next_segment_idx += 1
        
        if answer_segments:
            qa_pair = {
                'question_id': f"q_{q_idx + 1}",
                'question_text': question.get('text', ''),
                'question_start_time': question.get('start_time', 0),
                'answer_text': ' '.join(seg.get('text', '') for seg in answer_segments),
                'answer_start_time': answer_segments[0].get('start_time', 0),
                'answer_end_time': answer_segments[-1].get('end_time', 0),
                'linked_segment_ids': [
                    question.get('segment_id', ''),
                    *[seg.get('segment_id', '') for seg in answer_segments]
                ]
            }
            qa_pairs.append(qa_pair)
        else:
            # No answer found
            qa_pair = {
                'question_id': f"q_{q_idx + 1}",
                'question_text': question.get('text', ''),
                'question_start_time': question.get('start_time', 0),
                'answer_text': '',
                'answer_start_time': 0,
                'answer_end_time': 0,
                'linked_segment_ids': [question.get('segment_id', '')]
            }
            qa_pairs.append(qa_pair)
    
    return qa_pairs


def prepare_segments_for_llm(transcript_data: Dict) -> List[Dict]:
    """Prepare transcript segments for LLM processing."""
    segments = transcript_data.get('segments', [])
    
    prepared_segments = []
    for i, segment in enumerate(segments):
        prepared_segment = {
            'segment_id': f"seg_{i}",
            'speaker': segment.get('speaker', f'SPEAKER_{i}'),
            'text': segment.get('text', ''),
            'start_time': segment.get('start_time', 0),
            'end_time': segment.get('end_time', 0),
            'duration': segment.get('duration', 0)
        }
        prepared_segments.append(prepared_segment)
    
    return prepared_segments


def save_corrected_transcript(corrected_segments: List[Dict], output_path: str):
    """Save corrected transcript as JSON."""
    output_data = {
        'metadata': {
            'phase': 4,
            'description': 'Speaker Attribution Correction + Q/A Mapping',
            'model_used': 'qwen2.5:3b-instruct',
            'processing_timestamp': datetime.now().isoformat(),
            'total_segments': len(corrected_segments)
        },
        'segments': corrected_segments
    }
    
    with open(output_path, 'w') as f:
        json.dump(output_data, f, indent=2)


def save_qa_mapping(qa_pairs: List[Dict], output_path: str):
    """Save Q/A mapping as JSON."""
    output_data = {
        'metadata': {
            'phase': 4,
            'description': 'Question-Answer Mapping',
            'mapping_method': 'deterministic',
            'processing_timestamp': datetime.now().isoformat(),
            'total_qa_pairs': len(qa_pairs)
        },
        'qa_pairs': qa_pairs
    }
    
    with open(output_path, 'w') as f:
        json.dump(output_data, f, indent=2)


def process(transcript_path: str, output_dir: str = "data/intermediate/phase_04") -> Dict:
    """
    Main processing function for Phase 4 with LLM-based speaker correction.
    """
    print("🔧 Phase 4: Speaker Attribution Correction + Q/A Mapping (Local LLM)")
    print(f"📁 Input: {transcript_path}")
    print(f"📁 Output: {output_dir}")
    
    # Validate input
    transcript_path_obj = Path(transcript_path)
    if not transcript_path_obj.exists():
        raise FileNotFoundError(f"Transcript file not found: {transcript_path}")
    
    # Create output directory
    output_dir_obj = Path(output_dir)
    phase_output_dir = output_dir_obj / transcript_path_obj.stem.replace('_transcript', '')
    phase_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Initialize LLM client
    print("🤖 Initializing Ollama client...")
    ollama = OllamaClient()
    
    if not ollama.is_available():
        print("⚠️  Ollama not available, using fallback mode")
    else:
        print("✅ Ollama client ready")
    
    # Load and prepare transcript
    print("📖 Loading transcript...")
    transcript_data = load_transcript(transcript_path)
    segments = prepare_segments_for_llm(transcript_data)
    print(f"   Loaded {len(segments)} segments")
    
    # LLM-based speaker correction and classification
    print("🧠 Correcting speaker attribution...")
    corrected_segments = ollama.correct_speaker_and_classify(segments)
    print(f"   Processed {len(corrected_segments)} segments")
    
    # Save corrected transcript
    corrected_path = phase_output_dir / f"{transcript_path_obj.stem.replace('_transcript', '')}_corrected.json"
    save_corrected_transcript(corrected_segments, str(corrected_path))
    print(f"✅ Corrected transcript saved: {corrected_path}")
    
    # Deterministic Q/A mapping
    print("🔗 Creating Q/A mapping...")
    qa_pairs = deterministic_qa_mapping(corrected_segments)
    print(f"   Found {len(qa_pairs)} Q/A pairs")
    
    # Save Q/A mapping
    qa_path = phase_output_dir / f"{transcript_path_obj.stem.replace('_transcript', '')}_qa_mapping.json"
    save_qa_mapping(qa_pairs, str(qa_path))
    print(f"✅ Q/A mapping saved: {qa_path}")
    
    # Generate statistics
    stats = {
        'total_segments': len(corrected_segments),
        'interviewer_segments': len([s for s in corrected_segments if s['corrected_speaker_label'] == 'interviewer']),
        'candidate_segments': len([s for s in corrected_segments if s['corrected_speaker_label'] == 'candidate']),
        'question_segments': len([s for s in corrected_segments if s['segment_type'] == 'question']),
        'answer_segments': len([s for s in corrected_segments if s['segment_type'] == 'answer']),
        'other_segments': len([s for s in corrected_segments if s['segment_type'] == 'other']),
        'high_confidence': len([s for s in corrected_segments if s['confidence'] == 'high']),
        'medium_confidence': len([s for s in corrected_segments if s['confidence'] == 'medium']),
        'low_confidence': len([s for s in corrected_segments if s['confidence'] == 'low']),
        'qa_pairs_found': len(qa_pairs),
        'speaker_corrections': len([s for s in corrected_segments if s['original_speaker_label'] != s['corrected_speaker_label']]),
        'fallback_mode': ollama.fallback_mode
    }
    
    print(f"\n📊 Processing Statistics:")
    print(f"   Total segments: {stats['total_segments']}")
    print(f"   Interviewer segments: {stats['interviewer_segments']}")
    print(f"   Candidate segments: {stats['candidate_segments']}")
    print(f"   Question segments: {stats['question_segments']}")
    print(f"   Answer segments: {stats['answer_segments']}")
    print(f"   Other segments: {stats['other_segments']}")
    print(f"   Speaker corrections: {stats['speaker_corrections']}")
    print(f"   Q/A pairs found: {stats['qa_pairs_found']}")
    print(f"   Confidence - High: {stats['high_confidence']}, Medium: {stats['medium_confidence']}, Low: {stats['low_confidence']}")
    if stats['fallback_mode']:
        print(f"   ⚠️  Used fallback correction (LLM unavailable)")
    
    return {
        'corrected_transcript_path': str(corrected_path),
        'qa_mapping_path': str(qa_path),
        'corrected_segments': corrected_segments,
        'qa_pairs': qa_pairs,
        'statistics': stats
    }


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python process.py <transcript_path>")
        sys.exit(1)
    
    transcript_path = sys.argv[1]
    try:
        result = process(transcript_path)
        print("\n🎉 Phase 4 completed successfully!")
        print(f"📁 Corrected transcript: {result['corrected_transcript_path']}")
        print(f"📁 Q/A mapping: {result['qa_mapping_path']}")
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)