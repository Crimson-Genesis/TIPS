import os
import json
import tempfile
import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock

from process import load_transcript, identify_speakers, is_question, is_answer, process


def test_load_transcript():
    """Test transcript loading function."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        test_data = {
            'segments': [
                {'speaker': 'SPEAKER_0', 'text': 'Hello', 'start_time': 0.0, 'end_time': 1.0, 'duration': 1.0}
            ]
        }
        json.dump(test_data, f)
        temp_path = f.name
    
    try:
        result = load_transcript(temp_path)
        assert 'segments' in result
        assert len(result['segments']) == 1
        assert result['segments'][0]['speaker'] == 'SPEAKER_0'
    finally:
        os.unlink(temp_path)


def test_identify_speakers():
    """Test speaker identification."""
    transcript_map = {
        'segments': [
            {'speaker': 'SPEAKER_0', 'text': 'What is your experience?', 'duration': 2.0, 'words': []},  # Short, question-like
            {'speaker': 'SPEAKER_1', 'text': 'I have five years of experience in software engineering working on various projects', 'duration': 5.0, 'words': []},  # Long, answer-like
            {'speaker': 'SPEAKER_0', 'text': 'Can you tell me more?', 'duration': 1.5, 'words': []},  # Short
            {'speaker': 'SPEAKER_1', 'text': 'Sure I worked on web development mobile apps and backend systems', 'duration': 4.0, 'words': []}  # Long
        ]
    }
    
    interviewer, candidate = identify_speakers(transcript_map)
    
    assert interviewer in ['SPEAKER_0', 'SPEAKER_1']
    assert candidate in ['SPEAKER_0', 'SPEAKER_1']
    assert interviewer != candidate
    print(f"Identified: Interviewer={interviewer}, Candidate={candidate}")


def test_is_question():
    """Test question detection."""
    # Should be detected as questions
    assert is_question("What is your experience?")
    assert is_question("How do you approach problems?")
    assert is_question("Can you explain this?")
    assert is_question("Tell me about your project?")
    assert is_question("Are you familiar with Python?")
    assert is_question("Do you have experience with databases?")
    
    # Should not be detected as questions
    assert not is_question("I have five years of experience")
    assert not is_question("The approach I used was")
    assert not is_question("In my previous role")


def test_is_answer():
    """Test answer detection."""
    # Should be detected as answers
    assert is_answer("I think the best approach is to use microservices")
    assert is_answer("Based on my experience we should implement")
    assert is_answer("For example we can use React for the frontend")
    assert is_answer("The solution involves creating a scalable architecture")
    assert is_answer("I implemented this using Python and Django")
    
    # Short responses might not be detected as answers
    assert not is_answer("Yes")
    assert not is_answer("Sure")


def test_process_file_not_found():
    """Test process with non-existent file."""
    try:
        process("nonexistent_transcript.json")
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError:
        pass


def test_process_success():
    """Test successful processing."""
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create test transcript file
        transcript_path = os.path.join(temp_dir, "test_transcript.json")
        
        transcript_data = {
            'total_duration': 30.0,
            'segments': [
                {'speaker': 'SPEAKER_0', 'start_time': 0.0, 'end_time': 3.0, 'duration': 3.0, 'text': 'What is your experience with Python?', 'language': 'en'},
                {'speaker': 'SPEAKER_1', 'start_time': 4.0, 'end_time': 10.0, 'duration': 6.0, 'text': 'I have five years of experience in software development', 'language': 'en'},
                {'speaker': 'SPEAKER_0', 'start_time': 12.0, 'end_time': 14.0, 'duration': 2.0, 'text': 'Can you tell me about your projects?', 'language': 'en'},
                {'speaker': 'SPEAKER_1', 'start_time': 15.0, 'end_time': 25.0, 'duration': 10.0, 'text': 'I worked on several projects including web applications and mobile apps', 'language': 'en'}
            ]
        }
        
        with open(transcript_path, 'w') as f:
            json.dump(transcript_data, f)
        
        result = process(transcript_path, output_dir=temp_dir + "/output")
        
        assert 'qa_path' in result
        assert 'qa_map' in result
        
        # Check Q/A map structure
        qa_map = result['qa_map']
        assert 'transcript_file' in qa_map
        assert 'speaker_mapping' in qa_map
        assert 'statistics' in qa_map
        assert 'qa_pairs' in qa_map
        
        # Check speaker mapping
        speaker_mapping = qa_map['speaker_mapping']
        assert 'interviewer' in speaker_mapping
        assert 'candidate' in speaker_mapping
        
        # Check Q/A pairs
        assert len(qa_map['qa_pairs']) >= 1
        for qa_pair in qa_map['qa_pairs']:
            assert 'question' in qa_pair
            assert 'answer' in qa_pair
            assert 'qa_id' in qa_pair


def test_process_creates_directory_structure():
    """Test that process creates correct directory structure."""
    with tempfile.TemporaryDirectory() as temp_dir:
        transcript_path = os.path.join(temp_dir, "test_transcript.json")
        
        transcript_data = {
            'total_duration': 20.0,
            'segments': [
                {'speaker': 'SPEAKER_0', 'start_time': 0.0, 'end_time': 2.0, 'duration': 2.0, 'text': 'What do you do?', 'language': 'en'},
                {'speaker': 'SPEAKER_1', 'start_time': 3.0, 'end_time': 8.0, 'duration': 5.0, 'text': 'I am a software engineer', 'language': 'en'}
            ]
        }
        
        with open(transcript_path, 'w') as f:
            json.dump(transcript_data, f)
        
        result = process(transcript_path, output_dir=temp_dir + "/output")
        
        expected_dir = Path(temp_dir + "/output/test")
        assert expected_dir.exists()
        
        expected_file = expected_dir / "test_qa_pairs.json"
        assert expected_file.exists()


if __name__ == "__main__":
    test_load_transcript()
    test_identify_speakers()
    test_is_question()
    test_is_answer()
    test_process_file_not_found()
    test_process_success()
    test_process_creates_directory_structure()
    print("All Phase 4 tests passed!")