#!/usr/bin/env python3

"""
Phase 4 — Speaker Attribution Correction + Question–Answer Mapping (Local LLM)

This phase corrects speaker labels using qwen2.5:3b-instruct and maps Q/A pairs deterministically.
"""

import sys
from pathlib import Path

def main():
    """Run Phase 4 on transcript file."""
    if len(sys.argv) != 2:
        print("Usage: python run_phase4.py <transcript_path>")
        print("Example: python run_phase4.py data/intermediate/phase_03/test_video/test_video_transcript.json")
        sys.exit(1)
    
    transcript_path = sys.argv[1]
    
    # Validate input
    if not Path(transcript_path).exists():
        print(f"❌ Error: Transcript file not found: {transcript_path}")
        sys.exit(1)
    
    print("🔧 Phase 4: Speaker Attribution Correction + Q/A Mapping (Local LLM)")
    print(f"📁 Input: {transcript_path}")
    print("🤖 Requirements: Ollama running with qwen2.5:3b-instruct")
    print()
    
    # Import and run Phase 4
    sys.path.append(str(Path(__file__).parent / 'phases' / 'phase_04_qa_segmentation'))
    from process import process
    
    try:
        result = process(transcript_path)
        print("\n🎉 Phase 4 completed successfully!")
        print(f"📁 Corrected transcript: {result['corrected_transcript_path']}")
        print(f"📁 Q/A mapping: {result['qa_mapping_path']}")
        print()
        print("📊 Results Summary:")
        print(f"   Total segments processed: {result['statistics']['total_segments']}")
        print(f"   Speaker corrections made: {result['statistics']['speaker_corrections']}")
        print(f"   Q/A pairs found: {result['statistics']['qa_pairs_found']}")
        print(f"   High confidence segments: {result['statistics']['high_confidence']}")
        print(f"   Medium confidence segments: {result['statistics']['medium_confidence']}")
        print(f"   Low confidence segments: {result['statistics']['low_confidence']}")
        
        if result['statistics'].get('fallback_mode'):
            print("   ⚠️  Used fallback correction (LLM unavailable)")
        else:
            print("   ✅ Used LLM-based correction")
            
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()