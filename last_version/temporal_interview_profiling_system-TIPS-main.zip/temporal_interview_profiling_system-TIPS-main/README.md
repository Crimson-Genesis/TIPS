# Interview Analyzer (CLI)

<!-- Badges -->

![Python](https://img.shields.io/badge/Python-3.11%2B-blue?style=for-the-badge)
![PyTorch](https://img.shields.io/badge/PyTorch-2.x-EE4C2C?style=for-the-badge)
![Whisper](https://img.shields.io/badge/Whisper-ASR-6A5ACD?style=for-the-badge)
![Local%20LLM](https://img.shields.io/badge/LLM-Local%20Inference-00b894?style=for-the-badge)
![Ollama](https://img.shields.io/badge/Ollama-qwen2.5%203B-orange?style=for-the-badge)
![Platform](https://img.shields.io/badge/Platform-Linux%20%7C%20macOS%20%7C%20Windows-black?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-Active%20Development-yellow?style=for-the-badge)

> **Local-first, phase-based CLI system for incremental interview analysis and job-fit evaluation from a single video.**

---

## Overview

**Interview Analyzer** is a strictly local, CLI-based system that evaluates a job candidate from a **single interview video**. The pipeline processes the interview **incrementally (question by question)**, producing auditable artifacts at each phase and culminating in **evidence-backed summaries and job-fit reasoning**.

The design enforces:

* deterministic preprocessing
* minimal and isolated LLM usage
* filesystem-based phase contracts
* full traceability from claims → answers → timestamps

---

## Core Principles

* **Single Input**: One interview video file (path only)
* **Incremental Processing**: State evolves after each Q/A pair
* **Phase Isolation**: Each phase produces explicit artifacts
* **Local-Only**: No cloud dependencies
* **Explainability**: Every conclusion references evidence
* **Safety by Design**: Git checkpoints + reversible phases

---

## Pipeline Phases

1. **Video Ingestion & Audio Extraction**
2. **Speaker Diarization**
3. **Speech Transcription**
4. **Speaker Correction + Q/A Mapping** *(Local LLM)*
5. **Deterministic Feature Extraction**
6. **Incremental Candidate Profile Construction**
7. **Incremental Summarization & Job-Fit Evaluation** *(Local LLM + JD)*

---

## Project Structure

```
interview_analyzer/
├── cli/
│   └── main.py
│
├── orchestrator/
│   └── pipeline.py
│
├── phases/
│   ├── phase_01_ingestion/
│   ├── phase_02_diarization/
│   ├── phase_03_transcription/
│   ├── phase_04_qa_segmentation/
│   ├── phase_05_feature_extraction/
│   ├── phase_06_incremental_profile/
│   └── phase_07_llm_summarization/
│
├── data/
│   ├── raw/
│   ├── intermediate/
│   └── final/
│
├── schemas/
│   └── candidate_profile.json
│
├── pyproject.toml
├── .gitignore
└── README.md
```

Each phase contains:

* `process.py` — phase logic
* `test_phase_xx.py` — deterministic tests

---

## Inputs

* **Interview Video** (required)
* **Job Description (.txt)** (required for Phase 7)

No other user inputs are accepted.

---

## Outputs

* Speaker-corrected transcripts
* Question–Answer mappings
* Feature vectors per answer
* Versioned candidate profile (JSON)
* Incremental summaries
* Evidence-based job-fit evaluation:

  * why the candidate fits
  * why the candidate does not fit
  * supporting answer IDs

All outputs are timestamped and stored on disk.

---

## LLM Policy

* **Runtime**: Ollama (local)
* **Model**: `qwen2.5:3b-instruct`
* **Allowed Phases**:

  * Phase 4: speaker correction + intent classification
  * Phase 7: summarization + job-fit reasoning

**Prohibited for LLMs**:

* audio/video access
* feature extraction
* re-diarization
* hiring decisions

LLM outputs must be **JSON-only** and schema-valid.

---

## Incremental Behavior

After each Q/A pair:

* candidate profile is updated
* a new summary is generated
* job-fit assessment may improve, degrade, or remain unchanged

Earlier summaries inform later ones but are never copied verbatim.

---

## Testing & Safety

* Deterministic tests per phase
* Git commit required after each phase
* Pipeline halts on failure with recovery instructions
* Artifacts are append-only and auditable

---

## Non-Goals

* Automated hiring decisions
* Candidate ranking or scoring
* Resume parsing
* Facial/emotion analysis
* Cloud execution
* UI / frontend

---

## Tags

`#cli` `#local-llm` `#ollama` `#qwen` `#nlp` `#speech-processing` `#interview-analysis`
`#incremental-pipeline` `#explainable-ai` `#offline-ai` `#ml-systems` `#engineering`

---

## License

MIT License

