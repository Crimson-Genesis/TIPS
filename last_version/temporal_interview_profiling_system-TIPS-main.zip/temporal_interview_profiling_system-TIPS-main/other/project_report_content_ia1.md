1. abstract
2. Introduction
    * Problem Statment
    * Motivation
3. System Requirments
4. Architecture Diagram
5. Literature Review
6. Data Collection / Dataset Description
7. Grantt Chart  / Project Timeline
8. Conclusion
