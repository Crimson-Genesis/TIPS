#!/usr/bin/env python

from graphviz import Digraph

dot = Digraph(
    name="Temporal Interview Profiling System",
    format="png",
    graph_attr={
        "rankdir": "TB",        # TOP TO BOTTOM
        "bgcolor": "white",
        "fontsize": "12",
        "fontname": "Helvetica"
    },
    node_attr={
        "shape": "box",
        "style": "rounded",
        "color": "black",
        "fontname": "Helvetica",
        "fontsize": "11"
    },
    edge_attr={
        "color": "black"
    }
)

# =========================
# Input Layer
# =========================
dot.node("Video", "Interview Video\n(Camera Feed)")
dot.node("Audio", "Interview Audio\n(Microphone Feed)")

# =========================
# Preprocessing
# =========================
dot.node(
    "Preprocess",
    "Preprocessing Layer\n"
    "- Frame Extraction\n"
    "- Audio Segmentation\n"
    "- Noise Handling"
)

# =========================
# Visual Pipeline
# =========================
dot.node(
    "FaceDetect",
    "Visual Processing\n"
    "- Face Detection\n"
    "- Face Alignment\n"
    "- Frame Normalization"
)

dot.node(
    "Emotion",
    "Visual Feature Extraction\n"
    "- Facial Expressions\n"
    "- Eye Contact\n"
    "- Head Pose"
)

# =========================
# Audio Pipeline
# =========================
dot.node(
    "AudioFeatures",
    "Audio Feature Extraction\n"
    "- Pitch\n"
    "- Energy\n"
    "- Speaking Rate\n"
    "- Pauses"
)

dot.node(
    "ASR",
    "Speech-to-Text (Planned)\n"
    "- Transcript Generation\n"
    "- Linguistic Features"
)

# =========================
# Fusion Layer
# =========================
dot.node(
    "Fusion",
    "Multimodal Feature Fusion\n"
    "- Audio + Visual + Text\n"
    "- Time-Window Alignment"
)

# =========================
# ML Layer
# =========================
dot.node(
    "TemporalModel",
    "Temporal ML Model (In Progress)\n"
    "- Sequential Analysis\n"
    "- Behavioral Pattern Learning"
)

dot.node(
    "Scoring",
    "Behavior Scoring\n"
    "- Confidence\n"
    "- Stress\n"
    "- Clarity"
)

# =========================
# Output Layer
# =========================
dot.node(
    "Summary",
    "Feedback & Summary Module\n"
    "- Human-readable Report\n"
    "- Interview Insights"
)

dot.node(
    "Output",
    "Final Output\n"
    "- Dashboard (Planned)\n"
    "- PDF / Text Report"
)

# =========================
# Flow Connections
# =========================
dot.edge("Video", "Preprocess")
dot.edge("Audio", "Preprocess")

dot.edge("Preprocess", "FaceDetect")
dot.edge("FaceDetect", "Emotion")

dot.edge("Preprocess", "AudioFeatures")
dot.edge("AudioFeatures", "ASR")

dot.edge("Emotion", "Fusion")
dot.edge("ASR", "Fusion")
dot.edge("AudioFeatures", "Fusion")

dot.edge("Fusion", "TemporalModel")
dot.edge("TemporalModel", "Scoring")
dot.edge("Scoring", "Summary")
dot.edge("Summary", "Output")

# =========================
# Render
# =========================
dot.render("interview_profiling_architecture_TB", cleanup=True)

print("Top-to-bottom architecture diagram generated successfully.")
