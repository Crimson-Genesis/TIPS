#!/usr/bin/env python

#!/usr/bin/env python

from graphviz import Digraph

dot = Digraph(
    name="Temporal Interview Profiling System",
    format="png",
    graph_attr={
        "rankdir": "TB",        # TOP TO BOTTOM
        "bgcolor": "white",
        "fontsize": "12",
        "fontname": "Helvetica",
        "nodesep": "0.4",
        "ranksep": "0.5"
    },
    node_attr={
        "shape": "box",
        "style": "rounded",
        "color": "black",
        "fontname": "Helvetica",
        "fontsize": "11"
    },
    edge_attr={
        "color": "black"
    }
)

# =========================
# Layered Compact Blocks
# =========================

dot.node(
    "Input",
    "Interview Input\n(Video + Audio)"
)

dot.node(
    "Features",
    "Feature Extraction Layer\n"
    "• Visual Cues\n"
    "• Audio Cues"
)

dot.node(
    "Fusion",
    "Multimodal & Temporal Analysis\n"
    "• Feature Fusion\n"
    "• Time-Based Modeling"
)

dot.node(
    "Scoring",
    "Behavior Evaluation\n"
    "• Confidence\n"
    "• Stress\n"
    "• Clarity"
)

dot.node(
    "Output",
    "Output & Feedback\n"
    "• Summary Report\n"
    "• Dashboard / PDF"
)

# =========================
# Flow
# =========================
dot.edge("Input", "Features")
dot.edge("Features", "Fusion")
dot.edge("Fusion", "Scoring")
dot.edge("Scoring", "Output")

# =========================
# Render
# =========================
dot.render("interview_profiling_architecture_layered_compact", cleanup=True)

print("Compact layered architecture diagram generated successfully.")

